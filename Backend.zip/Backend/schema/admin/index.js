
import AdminSchema from "./admin";


module.exports = {
  AdminSchema

};
