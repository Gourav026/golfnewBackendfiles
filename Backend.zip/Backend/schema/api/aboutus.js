var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;

var aboutUsSchema = new Schema({
    description: { type: String, default: '' },
    status: { type: Boolean,  default: true  }

    }, 
    {
            timestamps: true
    });


aboutUsSchema.plugin(mongoosePaginate);
aboutUsSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('AboutUs', aboutUsSchema);