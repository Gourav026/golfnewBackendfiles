let mongoose=require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

let Schema = mongoose.Schema;

let PetitionSchema=new Schema({
    userId:      { type: mongoose.Schema.ObjectId },
    roundId:     { type: mongoose.Schema.ObjectId },
    signedStatus:{ type: String , enum:['Pending','Done'], default:'Pending'  }
},{
    timestamps: true
});

// Validate petition is not taken
PetitionSchema
  .path('roundId')
  .validate(async function(value) {
     let petitionExist = await this.constructor.findOne({ roundId: value, userId:this.userId })
      if (petitionExist  && this.isNew) {
        //console.log('petitionExist------>',petitionExist)
        return false;
      }
      return true;  
  }, 'The specified petition is already submitted.');

PetitionSchema.plugin(mongoosePaginate);
PetitionSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Petition', PetitionSchema);