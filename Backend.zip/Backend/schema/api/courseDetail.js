var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var CourseDetailSchema = new Schema({ 
            courseId        : { type: mongoose.Schema.ObjectId },
            holeNumber      : { type: Number},
            imageType       : { type: String },
            photo           : { type: String },
            imageMediumPath : { type: String },
            imageThumbPath  : { type: String },
            par             : { type: Number},
            strokeIndex     : { type: Number},            
            blueYard        : { type: Number , default:0},
            whiteYard       : { type: Number , default:0},
            yellowYard      : { type: Number , default:0},
            redYard         : { type: Number , default:0},
            scoringAverage  : { type: Number},
            firstLatitude   : { type: Number},
            firstLongitude  : { type: Number},
            secondLatitude  : { type: Number},
            secondLongitude : { type: Number},
            rotateDegree    : { type: String},
            geoLocation     : {
                                type: [Number],
                                index: '2d'
                              },
          CenterLatLong : {
                                latitude: { type: Number},
                                longitude: { type: Number},
                                latitudeDelta:{ type: Number},
                                longitudeDelta: { type: Number},
                             },                  

    }, 
    {
     timestamps: true
    });

CourseDetailSchema.plugin(mongoosePaginate);
CourseDetailSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('CourseDetail', CourseDetailSchema);