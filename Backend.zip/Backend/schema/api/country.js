var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var CountrySchema = new Schema({ 
            name          : { type: String},
            status        : { type: Boolean, default:true}
    }, 
    {
     timestamps: true
    });

// Validate empty name
CountrySchema
  .path('name')
  .validate(function(name) {
    return name.length;
  }, 'name cannot be blank');

// Validate name is not taken
CountrySchema
  .path('name')
  .validate(async function(value) {
    
    let countryExist = await this.constructor.findOne({ name: value })
    console.log('this.isNew------>',this)
    
    if (countryExist && this.isNew) {
      console.log('countryExist------>',countryExist)
  
      return false;
    }
    return true;  
  }, 'The specified name address is already in use.');

CountrySchema.plugin(mongoosePaginate);
CountrySchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Country', CountrySchema);