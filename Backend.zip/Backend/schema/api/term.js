var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var termSchema = new Schema({
    description: { type: String, default: '' },
    status: { type: Boolean,  default: true  }
    }, 
    {
            timestamps: true
    });


termSchema.plugin(mongoosePaginate);
termSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Term', termSchema);