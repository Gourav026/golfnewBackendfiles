let mongoose =require("mongoose");

let Schema=mongoose.Schema;

let FaqSchema=new Schema({
    title:{type: String},
    description:{type:String},
    status:{type:Boolean,default:true}
},
{
    timestamps:true
});

module.exports=mongoose.model('Faq',FaqSchema);