var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var RoundSchema = new Schema({
            courseId        : { type: mongoose.Schema.ObjectId, default: '' },
            name            : { type: String, default: '' },
            startingHole    : { type: Number, default: 1 },
            modeSelection   : [{ type: String }],   
            player1         : { type: mongoose.Schema.ObjectId },
            player2         : { type: mongoose.Schema.ObjectId },
            player3         : { type: mongoose.Schema.ObjectId },
            player4         : { type: mongoose.Schema.ObjectId },
            lastUpdatedHole : { type: Number , default:null},
            lastRecordBy    : { type: mongoose.Schema.ObjectId },
            status          : { type: Boolean, default: true }
    }, 
    {
     timestamps: true
    });

RoundSchema.plugin(mongoosePaginate);
RoundSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Round', RoundSchema);