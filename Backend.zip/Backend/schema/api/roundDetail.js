var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');


var Schema = mongoose.Schema;
var RoundDetailSchema = new Schema({
            roundId        : { type: mongoose.Schema.ObjectId },
            holeNumber     : { type: Number, default: 0 },
            par            : { type: Number, default: 0 },      
            si             : { type: Number, default: 0 },      
            location       : { type: String, default: '' },       
            scoreDetail    : [{
                                team        : { type: String },      
                                playerId    : { type: mongoose.Schema.ObjectId },
                                score       : { type: Number },
                                isEditable  : { type: Boolean, default:true },
                                highlight   : { type: Boolean, default:false },
                               
                                result      : {
                                  team        : { type: String },      
                                  status      : { type: String }  
                               },
                               subTotal       : { type: Object }   
                             }],
            result         : {
                                team        : { type: String },      
                                status      : { type: String, default: '' }  
                             },
            subTotal       : { type: Object },
            geoLocation    : {
                                type: [Number],
                                index: '2d'
                             }
    }, 
    {
     timestamps: true
    });

RoundDetailSchema.plugin(mongoosePaginate);
RoundDetailSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('RoundDetail', RoundDetailSchema);