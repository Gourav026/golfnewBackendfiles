var joibird = require('joibird')

class InsuaranceformTempValidator {
	//validate create new data
	static validateCreating(body)  {
		var schema = joibird.object().keys({

	    name: joibird.string().min(2).required().options({
	    	language: {
	    		key: 'FirstName ',
	    		string: {
	    			min: 'must be greater than or equal to 2 characters'
	    		}
	    	}
		}),

		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
	
	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    name: joibird.string().regex(/^[a-zA-Z][a-zA-Z0-9]*$/).max(40).options({
	    	language: {
	    		key: 'Name ',
	    		string: {
	    			regex: {
	    				base : 'must be alphabetic',
	    				name: 'must be alphabetic'
	    			},
	    			max: 'must be less than or equal to 40 characters'
	    		}
	    	}
	    })
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
}

module.exports = InsuaranceformTempValidator;
