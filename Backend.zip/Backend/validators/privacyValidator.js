var joibird = require('joibird')

class PrivacyValidator {
	//validate create new data
	static validateCreating(body)  {
		var schema = joibird.object().keys({

			description: joibird.string().required().options({
				language: {
					key: 'description ',
					string: {
						min: 'description required'
					}
				}
			})

		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
	
	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    id: joibird.string().required().options({
	    	language: {
	    		key: 'id ',
	    		string: {
	    			min: 'id required'
	    		}
	    	}
		})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
}

module.exports = PrivacyValidator;
