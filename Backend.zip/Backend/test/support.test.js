const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { UserSchema } = require('../schema/api')
var beforeEach = require('mocha').beforeEach;
const { setupDatabase , userOne} = require('./utils/authentication')
const userId = new mongoose.Types.ObjectId()

beforeEach(setupDatabase);



//---------------Leadeboardstatistic start--------------//


describe('GET /api/v1/leaderBoardStatistic', function() {
    it('Should get all leaderBoardStatistic ', function(done) {
      request(app)
        .get('/api/v1/leaderBoardStatistic')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  


  
  //---------------Faq start--------------//


describe('GET /api/v1/faq', function() {
    it('Should get all faq ', function(done) {
      request(app)
        .get('/api/v1/faq')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



  //---------------Help start--------------//


describe('GET /api/v1/help', function() {
    it('Should get all help ', function(done) {
      request(app)
        .get('/api/v1/help')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  


    //---------------Privacy start--------------//


describe('GET /api/v1/privacy', function() {
    it('Should get all privacy ', function(done) {
      request(app)
        .get('/api/v1/privacy')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  