const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { UserSchema } = require('../schema/api')
var beforeEach = require('mocha').beforeEach;
const { setupDatabase , userOne} = require('./utils/user')
const userId = new mongoose.Types.ObjectId()

//beforeEach(setupDatabase);


  /*
   * START
   * Test Case For Register a User
   */

      // describe('POST /api/v1/users/register', function() {
      //     it('Should register a new user', function(done) {
      //       request(app)
      //         .post('/api/v1/users/register')
      //         .send({
      //             "firstName":"registerfirstnameuser",
      //             "lastName":"registerlastnameuser",
      //             "email":"registeruser@gmail.com",
      //             "contactNumber":"7003544591",
      //             "password":"123456"
      //         })
      //         .expect(200)
      //         .end(function(err, res) {
      //           if (err) return done(err);
      //           return done();
      //         });
      //     });
      //   });

  /*
   * END
   * Test Case For Register a User
   */


  /*
   * START
   * Test Case For Find Specific User
   */   

      // describe(`GET /api/v1/users/`, function() {
      //   it('Should get specific user', function(done) {
      //     request(app)
      //       .get(`/api/v1/users/`)
      //       .send({
      //         _id:userOne._id
      //       })
      //       .expect(200)
      //       .end(function(err, res) {
      //         if (err) return done(err);
      //         return done();
      //       });
      //   });
      // });   

  /*
   * END
   * Test Case For Find Specific User
   */

 
  
 

 
      /*
   * START
   * Test Case For User Login With Email verify
   */  

  
      describe(`PUT /api/v1/userEmailVerification/${userOne._id}`, function() {
        it('User logs in', function(done) {
          request(app)
            .put(`/api/v1/userEmailVerification/${userOne._id}`)
            .set('authorization',`Bearer ${userOne.authToken}`)
            .send({emailVerifiedToken:'',emailVerify:true})        
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  



         /*
   * END
   * Test Case For User Login With Email verify
   */  
