const mongoose = require('mongoose')
const {UserSchema} = require('../../schema/api')
const {UserBusiness,CourseBusiness,CourseDetailBusiness} = require('../../businesses/')


var { signToken } =require('../../auth/auth.service')

const userOneId     = new mongoose.Types.ObjectId()

const userOne = {
    _id: userOneId,
    "firstName":"TestUser",
    "lastName":"lastname",
    "email":"testuser@gmail.com",
    "contactNumber":"7003544591",
    "emailVerify":true,
    "password":"123456",
    "authToken": signToken(userOneId,'user')
}



    

const setupDatabase = async () => {
    let getUsers =  await UserSchema.find({}) 
   
   
    await UserSchema.deleteMany()
    await UserSchema.create(userOne)
   
}
    


module.exports = {
    userOne,
    setupDatabase,
   

}