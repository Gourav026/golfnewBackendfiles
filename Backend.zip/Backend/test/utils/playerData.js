 playerDatatoUpdate=(userData)=>{
    let friends=[]
    userData.friendList.map(friendId=>{

        friends.push(friendId._id) 
    })
    //console.log("userData=",userData)
    userData={
        _id:userData._id,
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email,
        contactNumber: "8282807337",
        friendList:friends,
        deviceId: userData.deviceId[0],
        password: "123456",
        emailVerify:true
    }

    return userData
}

module.exports= playerDatatoUpdate