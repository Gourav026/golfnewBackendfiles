const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { StateSchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,setupDatabase ,courseOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()
const axios = require('axios').default;
const {UserSchema,CourseSchema} = require('../schema/api')
const  playerDatatoUpdate=require('./utils/playerData')



let roundData={}
let roundDetail=[]
userIds=["6095fa5cd98b4c411aab92bf","60a36597603e1c4b3ea96f33","60a3676d603e1c4b3ea96f35","60a36838603e1c4b3ea96f36"]




describe('GET /api/v1/round', function() {
  it('Get the selected round', function(done) {

    console.log("in scorecard entry---------------------------------------------------------------------")
    request(app)
    .get('/api/v1/round')
    .expect('Content-Type', /json/)
    .expect(200)
    .end(function(err, res) {
      if (err) return done(err);
      roundData=res.body.response[0].data;
      //console.log("roundata=",roundData);
      roundDetail=roundData.roundDetails
      //console.log("roundetail=",roundDetail[0]);
       return done();
      });
  });
});  

describe('GET /api/v1/roundDetail', function() {
  it('Get the selected score', function(done) {
    request(app)
      .get('/api/v1/roundDetail')
      .expect('Content-Type', /json/)
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        roundDetail=res.body.response[0].data;
      //console.log("roundetail=",roundDetail[0]);
       return done();
      });
  });
});  


describe(`PUT /api/v1/roundDetail`, function() {

  it('Update values in the score detail', function(done) {
    request(app)
      .put(`/api/v1/roundDetail/${roundDetail[0]._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)
     .set('Content-Type', 'application/json')
      .send({
        "roundId":roundDetail[0].roundId._id,
        "holeNumber": 1,
        "scoreDetail": [
          {
            "isEditable" : true,
            "_id" : `${roundDetail[0].scoreDetail[0]._id}`,
            "playerId" : `${userOne._id}`,
            "score" : 2
          },
          {
            "isEditable" : true,
            "_id" : `${roundDetail[0].scoreDetail[1]._id}`,
            "playerId" : `${roundDetail[0].scoreDetail[1].playerId}`,
            "score" : 4
          }
        ]
     })        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  


