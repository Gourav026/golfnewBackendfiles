'use strict';

var { StatisticBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class StatisticController {
  /**
   * Get list of LeaderBoardStatistic
   */
  static leaderBoardStatistic(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('leaderBoardStatistic hitted',req.query);
      
    return StatisticBusiness.leaderBoardStatistic(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Course Statistic', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }
    /**
   * Get list of coursewiseLeaderBoardStatistic
   */
  static coursewiseLeaderBoardStatistic(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('coursewiseLeaderBoardStatistic hitted',req.query);
      
    return StatisticBusiness.coursewiseLeaderBoardStatistic(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Course Statistic', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }


  static playerwiseLeaderBoardStatistic(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    
		if(!req.query.playerId){
      handleResponse(res, 200, 'PlayerId required', {})
    }
      
    return StatisticBusiness.playerwiseLeaderBoardStatistic(req.query)
    .then((data) => {
      ////console.log('data',data)
      handleResponse(res, 200, 'Player Round Detail', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

}

module.exports = StatisticController;
