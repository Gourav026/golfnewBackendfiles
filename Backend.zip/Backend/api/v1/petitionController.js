'use strict'

let {PetitionValidator} =require('../../validators')
const {PetitionBusiness, UserBusiness, RoundDetailBusiness } = require('../../businesses')
var mailProperty = require('../../modules/sendMail');
var config = require('../../config/environment')

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
  }


class PetitionController{
    
    /**
     * Get list of petition
     */
    static index(req, res) {
        if(req.query.limit!='undefined'){
                req.query.limit = parseInt(req.query.limit);
            }
            if(req.query.offset!='undefined'){
                req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return PetitionBusiness.find(req.query)
        .then((data) => {
        console.log('data',data)
        handleResponse(res, 200, 'Petition List', data)
        })
        .catch((err) => {
        handleResponse(res, 500, err.message, err)
        });
    }

//========================================create new Petition ====================================
    static create(req,res,next)
    {
        PetitionValidator.validateCreating(req.body)
        .then(petitions=>{

            petitions.signedStatus=req.body.signedStatus?req.body.signedStatus:'Pending';
            petitions.userId=req.body.userId;
            petitions.roundId=req.body.roundId;
            console.log('petitions-->',petitions);

            PetitionBusiness.create(petitions)
            .then((data)=>{
                console.log('data-->',data);
                if(data.errors)
                {
                    validationError(res, 422, data._message, data.errors)
                }else{
                    
                    UserBusiness.findOne({_id: petitions.userId})
                    .then(async user => {
                      if (!user.email) {
                        return handleResponse(res, 200, 'User Email Not Exist.Scorecard added Successfully.Please contact Administrator ',true, data)
                      }else{
                        let htmlData= ''
                        let htmlHeaderData= ''
                        let headerInfo= []
                        
                        let roundDetailBusiness = await RoundDetailBusiness.find({roundId:petitions.roundId})
                        if(roundDetailBusiness.length> 0)
                        {
                            console.log('roundDetailBusiness',roundDetailBusiness);
                            new Promise( (resolve, reject) => { 
                            roundDetailBusiness[0].resource[0].userId.map( (data)=> {
                                headerInfo.push(data._id)
                                resolve(headerInfo)
                                htmlHeaderData = htmlHeaderData + `
                                 <th><img src="https://golfernet-backend.herokuapp.com${data.photo}" height=30 width=30 /></th>
                            `
                              })
                            })
        
                            roundDetailBusiness[0].data.map( async (data)=> {
                                htmlData = htmlData + `<tr>
                                <td>${data.holeNumber}</td>
                                <td>${data.par}</td>
                                <td>${data.si}</td>`;
        
                                data.scoreDetail
                                .map(function (sc,i) { 
        
                                  let scorecard = data.scoreDetail.filter( score => score.playerId == headerInfo[i].toString())
                                 
                                  htmlData+=`<td>${scorecard.length > 0 ? scorecard[0].score != null ? scorecard[0].score :'' : ''}</td>`
                              })
                                htmlData+= `</tr>`
                            })
        
                        }
                        
                        let html = `<!DOCTYPE html>
                        <html>
                        <head>
                        <style>
                        table {
                          font-family: arial, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                        }
                        
                        td, th {
                          border: 1px solid #dddddd;
                          text-align: left;
                          padding: 8px;
                        }
                        
                        tr:nth-child(even) {
                          background-color: #dddddd;
                        }
                        </style>
                        </head>
                        <body>
                        
                        <h2>Score Card</h2>
                        
                        <table>
                          <tr>
                            <th>Hole Number</th>
                            <th>Par</th>
                            <th>SI</th>
                            ${htmlHeaderData}
                          </tr>
                          ${htmlData}
                        </table>
                        
                        </body>
                        </html>
                        `
                        //signedPetition/:userId/:roundId
                        mailProperty('petition')(user.email, {
                            name                    : `${user.firstName} ${user.lastName}`,
                            email                   : user.email,
                            account_verify_link    : config.liveUrl+'signedPetition/'+petitions.userId+'/'+petitions.roundId,
                            date                    : new Date(),
                            html                    : html
                        },true,html,`${user.firstName}-${user.lastName}-${petitions.userId}-${petitions.roundId}`).send();
        
                        handleResponse(res, 200, 'Petition description Added Successfully', data) 
                      }
                    })
   
                }
            })
            .catch((err)=>{
                console.log("err=",err);
                handleResponse(res, 500, err, err)
            })
        })
        .catch((err)=>{
            console.log("validation error.,",err);
            validationError(res, 422, err, err);
        })

    }
//========================================create new Petition =====================================

//========================================Update Petition =========================================

    static update(req, res, next)
    {
        PetitionValidator.validateUpdating({...req.body, ...req.params})
        .then(petition=>{
            let petitionsId=req.params.id;
            let fileType='';
            PetitionBusiness.findOne({_id:petitionsId})
                .then(petitions =>{
                    if(!petitions)
                    {
                        handleResponse(res, 500, 'Petition does Not Exist', {}) 
                    }
                    petitions.signedStatus=req.body.signedStatus?req.body.signedStatus:petitions.signedStatus;
                    petitions.userId=req.body.userId?req.body.userId:petitions.userId;
                    petitions.roundId=req.body.roundId?req.body.roundId:petitions.roundId;

                    PetitionBusiness.update(petitions)
                    .then(data=>{
                        handleResponse(res,200,"petition updated successfully",data)
                    })
                    .catch(err=>{
                        handleResponse(res,500,err,err);
                    })
                })
                .catch((err)=>{
                    console.log("sending err",err);
                    handleResponse(res, 500, err.message, err);
                });
        })
        .catch(err => 
            validationError(res, 422, err.cause.details[0].message, err)
        );
    }

//========================================Update Petition =========================================

//========================================Delete Petition =========================================

    /**
   * Deletes a newsFeed
   * restriction: 'newsFeed'
   */
  static delete(req, res) {

    PetitionValidator.validateUpdating(req.params).then(petitions => {

        PetitionBusiness.findOne({_id: req.params.id})
        .then(petitions => {

            return PetitionBusiness.delete(req.params.id)
            .then((data) => {

                console.log('data',data)
                handleResponse(res, 200, 'Petition Deleted Successfully', data)
                
            })
            .catch((err) => {
                handleResponse(res, 500, err.message, err)
            });
        
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }
//========================================Delete Petition =========================================


}
module.exports=PetitionController;