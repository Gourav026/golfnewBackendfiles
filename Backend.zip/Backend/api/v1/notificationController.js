'use strict'

let {NotificationValidator} =require('../../validators')
const {NotificationBusiness, UserBusiness } = require('../../businesses')
var mailProperty = require('../../modules/sendMail');
var config = require('../../config/environment');
var fcmNotification = require('../../modules/fcmNotification');

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
  }


class NotificationController{
    
    /**
     * Get list of petition
     */
    static index(req, res) {
        if(req.query.limit!='undefined'){
                req.query.limit = parseInt(req.query.limit);
            }
            if(req.query.offset!='undefined'){
                req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return NotificationBusiness.find(req.query)
        .then(async (data) => {
        // await fcmNotification.fcmSentPush(data, 'fFY5bp7dQvanCPjXxCqcaa:APA91bHVe6k8Wvmbcld11JukfQA25cFidK5sTNZNZJi0dEMoTE_FhqE_GdIbKqPKvnjueWA21wqX39Ho01J_srI4kcFFqRi4It710wGT9FmbeKZIUopZBtEEZgDd8DFrq9hU-F16tJVK', '')
        // console.log('data',data)
        handleResponse(res, 200, 'Notification List', data)
        })
        .catch((err) => {
        handleResponse(res, 500, err.message, err)
        });
    }
    
    /**
     * Get list of petition
     */
    static send(req, res) {
        console.log(req.body);
        if(!req.body.userId){
            validationError(res, 422, 'user Id Required', {})
        }
        console.log('index hitted',req.body.userId);
        
        UserBusiness.findOne({_id: req.body.userId})
        .then(async user => {
            console.log(user);
          if (!user.deviceId) {
            return handleResponse(res, 200, 'User deviceId not exist.Please contact Administrator ',true, user)
          }else{
            let notificationData = {
                title:'Test Message',
                excludeUserId : user._id,
                toUser   : user._id,
            }
            await fcmNotification.fcmSentPush(notificationData, user.deviceId, 'this is test message')

            handleResponse(res, 200, 'Notification send successfully', user) 
          }
        })
        .catch((err) => {
        handleResponse(res, 500, err.message, err)
        });
    }
//========================================create new Notification ====================================
    static create(req,res,next)
    {
        NotificationValidator.validateCreating(req.body)
        .then(notification=>{

            notification.message=req.body.message;
            notification.fromUser=req.body.fromUser;
            notification.toUser=req.body.toUser;
            notification.type=req.body.type;

            NotificationBusiness.create(notification)
            .then((data)=>{
                console.log('data-->',data);
                if(data.errors)
                {
                    validationError(res, 422, data._message, data.errors)
                }else{
                    
                   handleResponse(res, 200, 'Notification Added Successfully', data) 
                      
                }
            })
            .catch((err)=>{
                console.log("err=",err);
                handleResponse(res, 500, err, err)
            })
        })
        .catch((err)=>{
            console.log("validation error.,",err);
            validationError(res, 422, err, err);
        })

    }
//========================================create new Notification =====================================

//========================================Delete Notification =========================================

    /**
   * Deletes a newsFeed
   * restriction: 'newsFeed'
   */
  static delete(req, res) {

    NotificationValidator.validateUpdating(req.params).then(notification => {

        NotificationBusiness.findOne({_id: req.params.id})
        .then(notification => {

            return NotificationBusiness.delete(req.params.id)
            .then((data) => {

                console.log('data',data)
                handleResponse(res, 200, 'Notification Deleted Successfully', data)
                
            })
            .catch((err) => {
                handleResponse(res, 500, err.message, err)
            });
        
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }
//========================================Delete Notification =========================================


}
module.exports=NotificationController;