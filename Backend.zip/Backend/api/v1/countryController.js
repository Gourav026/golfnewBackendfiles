'use strict';
var { CountrySchema } = require('../../schema/api')
var { CountryBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { CountryValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class CountryController {
  /**
   * Get list of countrys
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CountryBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Country List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new country
   */
  static create(req, res, next) {

    CountryValidator.validateCreating(req.body).then(country => {
        country.name = req.body.name;
        country.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:true
             
        CountryBusiness.create(country)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'Country Added Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


  
  /**
   * DeleteAll country
   * restriction: 'admin'
   */
   static deleteAll(req, res) {

    if(process.env.PORT == '3004')
    {
   CountrySchema.find({})
    .then(async countries => {
      console.log('countries--',countries);
                  
            

              const removedUsers = await Promise.all(promises);

              const removedUser = await CountrySchema.deleteMany({})  // return Query;

                
              return CountryBusiness.find({})
              .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'Countries Deleted Successfully',true, data)
              })
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          }else{
            handleResponse(res, 500, 'Not Authorized',false, {})

          }
}

   /**
   * Update Profile Country
   */
  static update(req, res, next) {
    //TODO - update validator
    CountryValidator.validateUpdating({...req.body, ...req.params})
    .then(country => {
      console.log('req.files--->', req.files)
      var countryId = req.params.id;
      CountryBusiness.findOne({_id: countryId})
        .then(country => {
          if (!country) { 
            handleResponse(res, 500, 'Country Not Exist', {}) 
          }
          country.name = req.body.name?req.body.name:country.name;
          country.status = ( 
                          (req.body.status === true || req.body.status == 'true') || 
                          (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:country.status;

            CountryBusiness.update(country)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Country Updated Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a country
   * restriction: 'admin'
   */
  static delete(req, res) {

    CountryValidator.validateUpdating(req.params).then(country => {

        CountryBusiness.findOne({_id: req.params.id})
        .then(country => {

            return CountryBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Country deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = CountryController;
