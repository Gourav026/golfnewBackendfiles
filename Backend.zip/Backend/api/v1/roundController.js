'use strict';
var { CourseDetailSchema, UserSchema, RoundDetailSchema } = require('../../schema/api')
var { RoundBusiness, UserBusiness, RoundDetailBusiness, NotificationBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { RoundValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class RoundController {



  /**
   * Get list of users
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    //console.log('index hitted',req.query);    
    return RoundBusiness.find(req.query)
    .then((data) => {
      //console.log('data',data)
      handleResponse(res, 200, 'Round List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new round
   */
  static start(req, res, next) {
    
    var ObjectID = require('mongodb').ObjectID;
    req.body.courseId = req.body.data[0].courseId
    //console.log('req.body.data[0]---',req.body.data[0]);

    //console.log('req.body.data[0].name---',req.body.data[1].name);

    req.body.name = req.body.data[1].name
    req.body.modeSelection = req.body.data[2].modeSelection
    req.body.startingHole = req.body.data[3].startingHole
    req.body.player1 = req.body.data[4].player1
    if(req.body.data[5] && req.body.data[5].player2)
    {
      req.body.player2 = req.body.data[5].player2
    }
    if(req.body.data[6] && req.body.data[6].player3)
    {
      req.body.player3 = req.body.data[6].player3
    }
    if(req.body.data[7] && req.body.data[7].player4)
    {
      req.body.player4 = req.body.data[7].player4
    }

    //console.log('req.body---',req.body);

    RoundValidator.validateCreating(req.body).then(async round => {
      round.courseId      = req.body.courseId;
      round.player1       = req.body.player1 && req.body.player1._id ? req.body.player1._id : req.body.player1;
      round.player2       = req.body.player2 && req.body.player2._id ? req.body.player2._id : req.body.player2;
      round.player3       = req.body.player3 && req.body.player3._id ? req.body.player3._id : req.body.player3;
      round.player4       = req.body.player4 && req.body.player4._id ? req.body.player4._id : req.body.player4;
      round.modeSelection = req.body.modeSelection;
      round.name          = req.body.name;
      round.startingHole  = req.body.startingHole;
      round.lastRecord    = req.body.lastRecord;
      round.lastRecordBy  = req.body.lastRecordBy;
      if(round.startingHole == 10)
      {
        round.lastUpdatedHole = 9
      }
      //console.log('ObjectID.isValid(round.player1)--->',ObjectID.isValid(round.player1));
      if(round.player1 && round.player1.contactNumber && !ObjectID.isValid(round.player1.contactNumber))
      {
        let user = {}

        user.firstName     = round.player1.firstName || 'Unknown';
        user.lastName      = round.player1.lastName || 'NA';
        user.contactNumber = round.player1.contactNumber;
        user.password      = round.player1.contactNumber;
        user.isSpecial     = true;
        //console.log('user---',user);
        ////console.log('invalid');
        let specialUser = await UserBusiness.registerSpecialCaseUser(user)
        //console.log('specialUser---------------->',specialUser);
        round.player1       = specialUser._id;

      }  
      if(round.player2  && round.player2.contactNumber && !ObjectID.isValid(round.player2.contactNumber))
      {
        let user = {}

        user.firstName     = round.player2.firstName || 'Unknown';
        user.lastName      = round.player2.lastName || 'NA';
        user.contactNumber = round.player2.contactNumber;
        user.password      = round.player2.contactNumber;
        user.isSpecial     = true;
        //console.log('user---',user);
        ////console.log('invalid');
        let specialUser = await UserBusiness.registerSpecialCaseUser(user)
        //console.log('specialUser---------------->',specialUser);
        round.player2       = specialUser._id;

      } 
      if(round.player3  && round.player3.contactNumber  && !ObjectID.isValid(round.player3.contactNumber))
      {
        let user = {}

        user.firstName     = round.player3.firstName || 'Unknown';
        user.lastName      = round.player3.lastName || 'NA';
        user.contactNumber = round.player3.contactNumber;
        user.password      = round.player3.contactNumber;
        user.isSpecial     = true;
        //console.log('user---',user);
        ////console.log('invalid');
        let specialUser = await UserBusiness.registerSpecialCaseUser(user)
        //console.log('specialUser---------------->',specialUser);
        round.player3       = specialUser._id;

      } 
      if(round.player4  && round.player4.contactNumber && !ObjectID.isValid(round.player4.contactNumber))
      {
        let user = {}

        user.firstName     = round.player4.firstName || 'Unknown';
        user.lastName      = round.player4.lastName || 'NA';
        user.contactNumber = round.player4.contactNumber;
        user.password      = round.player4.contactNumber;
        user.isSpecial     = true;
        //console.log('user---',user);
        ////console.log('invalid');
        let specialUser = await UserBusiness.registerSpecialCaseUser(user)
        //console.log('specialUser---------------->',specialUser);
        round.player4       = specialUser._id;

      }     
      round.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true

        RoundBusiness.start(round)
          .then(async (data) => {
            //console.log('data---',data);
            let user = { latestRoundId:data._id }
            let players = []

            let userDetail     = await UserSchema.findOne({_id:data.player1})
            //console.log("userDetails=",userDetail);
            let playerFriend   = userDetail.friendList ? userDetail.friendList : []
            let onScreenNotification   = userDetail.setting ? userDetail.setting.onScreenNotification : false

            let notification ={}
            notification.message=`You have received a friend request from ${userDetail.firstName} ${userDetail.lastName}`;
            notification.fromUser=userDetail._id;
            notification.type='friend request';

            if(data.player1){
              user._id        = data.player1
              players.push(user._id)
              await UserBusiness.updateByQuery(user)
            }

            if(data.player2){
              user._id = data.player2
              players.push(user._id)
              if(!playerFriend.includes(user._id))
              {
                playerFriend.push(user._id)
              }
              await UserBusiness.updateByQuery(user)
                
              notification.toUser=user._id;
              let friendRequestNotified = await NotificationBusiness.findOne({fromUser: notification.fromUser,toUser: notification.toUser})
              let toUser = await UserBusiness.findOne({_id: notification.toUser})
              if(onScreenNotification){
              await RoundBusiness.sendNotification(friendRequestNotified, toUser, notification)
              }
            }

            if(data.player3){
              user._id = data.player3
              players.push(user._id)

              if(!playerFriend.includes(user._id))
              {
                playerFriend.push(user._id)
              }
              await UserBusiness.updateByQuery(user)  
              notification.toUser=user._id;
              
              let friendRequestNotified = await NotificationBusiness.findOne({fromUser: notification.fromUser,toUser: notification.toUser})
              let toUser = await UserBusiness.findOne({_id: notification.toUser})
              if(onScreenNotification){
                await RoundBusiness.sendNotification(friendRequestNotified, toUser, notification)
                }
            }

            if(data.player4){
              user._id = data.player4
              players.push(user._id)

              if(!playerFriend.includes(user._id))
              {
                playerFriend.push(user._id)
              }
              await UserBusiness.updateByQuery(user)  
              notification.toUser=user._id;
             
              let friendRequestNotified = await NotificationBusiness.findOne({fromUser: notification.fromUser,toUser: notification.toUser})
              let toUser = await UserBusiness.findOne({_id: notification.toUser})
              if(onScreenNotification){
                await RoundBusiness.sendNotification(friendRequestNotified, toUser, notification)
                }
            }

            let coursedetail = await CourseDetailSchema.find({courseId:round.courseId}).sort({holeNumber:1})
            //console.log('coursedetail--',coursedetail)
            let parTotal = coursedetail.map( (crsdetail) => {
              return crsdetail.par
            })
            
            let siTotal = coursedetail.map( (crsdetail) => {
              return crsdetail.strokeIndex
            })
            let inputData     = {}
            inputData.par     = parTotal
            inputData.si      = siTotal
            inputData.players = players
            inputData.roundId = data._id
           // //console.log('siTotal-------',siTotal);
            await RoundDetailBusiness.bulkInsert(inputData)

            await UserSchema.updateOne({_id:data.player1}, { $set : { friendList:playerFriend}})

          
            handleResponse(res, 200, 'Round Started', data)
            })
            .catch((err) => {
            handleResponse(res, 500, err.message, err)
            });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

   /**
   * Update Round
   */
  static update(req, res, next) {
    //TODO - update validator
    RoundValidator.validateUpdating({...req.body, ...req.params}).then(round => {
    //console.log('req.files--->', req.files)
    var roundId = req.params.id;
    RoundBusiness.findOne({_id: roundId})
      .then(async round => {
          if (!round) { 
            handleResponse(res, 500, 'round Not Exist', {}) 
          }
          //console.log('round-->',round);

          if(req.body.quitId){
            
            await RoundDetailSchema.updateMany({roundId: roundId, "scoreDetail.playerId":req.body.quitId }, {
              $set: {
                  "scoreDetail.$.isEditable": false
              }           
          });
          handleResponse(res, 200, 'Quit Successfully', {})

          }else{
            handleResponse(res, 200, 'Round Updated Successfully', {})

          }

          // RoundBusiness.update(round)
          // .then((data) => {
          //      //console.log('data',data)
          //      handleResponse(res, 200, 'Round Updated Successfully', data)
          // })
          // .catch((err) => {
          //   handleResponse(res, 500, err.message, err)
          // });
   
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Authentication callback
   */
  static authCallback(req, res, next) {
    res.redirect('/');
  }

}

module.exports = RoundController;
