'use strict';

var { FeedbackBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { FeedbackValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class FeedbackController {
  /**
   * Get list of states
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return FeedbackBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Feedback List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new state
   */
  static create(req, res, next) {

    FeedbackValidator.validateCreating(req.body).then(feedback => {
        feedback.userId = req.body.userId?req.body.userId:feedback.userId;
        feedback.title = req.body.title;
        feedback.description = req.body.description;
        
             
        FeedbackBusiness.create(feedback)
        .then((data) => {
            FeedbackBusiness.findOne({_id:data._id})
                .then((userData) => {
                console.log('userData',userData)
                if(userData.userId && userData.userId.email){

                      mailProperty('feedback')(userData.userId.email,
                    {
                        name                    : `${userData.userId.firstName} ${userData.userId.lastName}`,
                        date                    : new Date()
                      }).send();

                      handleResponse(res, 200, 'Feedback Added Successfully', data)

                }else{
                     handleResponse(res, 200, 'Feedback Added Successfully', data)

                }

                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
          console.log('data',data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }
}
module.exports = FeedbackController;
