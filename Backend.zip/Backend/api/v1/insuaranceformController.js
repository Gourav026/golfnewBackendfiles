'use strict';


var { InsuaranceformSchema } = require('../../schema/api')
var { InsuaranceformBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { InsuaranceformValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')


function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      success:false,
      response:data
    });
}

function handleResponse(res, statusCode, message, isSuccess, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        success:isSuccess,
        response:data
      });
}


class InsuaranceformController {
  /**
   * Get list of Insuaranceforms
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return InsuaranceformBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Insuaranceform List', true, data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, false, err)
    });
  }

  
  
  /**
   * Creates a new Insuaranceform
   */
  static create(req, res, next) {

    InsuaranceformValidator.validateCreating(req.body).then(Insuaranceform => {

      Insuaranceform.name = req.body.name || 'Unknown';
      Insuaranceform.age = req.body.age ;
      Insuaranceform.address = req.body.address;
      Insuaranceform.contactNumber = req.body.contactNumber;
      Insuaranceform.country = req.body.country;
      Insuaranceform.state = req.body.state;
      Insuaranceform.city = req.body.city;
      Insuaranceform.pin = req.body.pin ;
                  
        InsuaranceformBusiness.create(Insuaranceform)
        .then((data) => {
          
          console.log('data',data)
                 
          let Func =  Uploader.uploadImageWithAvatar;
          let Payload = {name:data.name,age:data.age};

           Func(Payload, data._id, 'Insuaranceforms', '/uploads/images/Insuaranceforms/', function(err, result) {
            console.log('result',result)
            
            if(result)
            {
              data.photo  = result.imageFullPath;
              data.imageMediumPath  = result.imageMediumPath;
              data.imageThumbPath  = result.imageThumbPath;
            }

            InsuaranceformBusiness.update(data)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Insuaranceform Register Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 200, err.message, false, err)
            });
          });
         // handleResponse(res, 200, 'Insuaranceform Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message,false, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }


   /**
   * Update Profile Insuaranceform
   */
  static update(req, res, next) {
    //TODO - update validator
    InsuaranceformValidator.validateUpdating({...req.body, ...req.params}).then(Insuaranceform => {
    console.log('req.files--->', req.files)
    console.log('req.body--->', req.body)
    var InsuaranceformId = req.params.id;
    InsuaranceformBusiness.findOne({_id: InsuaranceformId})
      .then(Insuaranceform => {
        if (!Insuaranceform) {
          return handleResponse(res, 200, 'Insuaranceform Not Exist',true, Insuaranceform)
        }
        Insuaranceform.name = req.body.name?req.body.name:Insuaranceform.name;
        Insuaranceform.age = req.body.age?req.body.age:Insuaranceform.age;
        Insuaranceform.address = req.body.address?req.body.address:Insuaranceform.address;
        Insuaranceform.contactNumber = req.body.contactNumber?req.body.contactNumber:Insuaranceform.contactNumber;
        Insuaranceform.country = req.body.country;
        Insuaranceform.state = req.body.state;
        Insuaranceform.city = req.body.city;
        Insuaranceform.geoLocation=req.body.geoLocation?req.body.geoLocation:Insuaranceform.geoLocation;
        Insuaranceform.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:Insuaranceform.status;

        if(req.body.setting!='' && typeof req.body.setting !='undefined'){

          let setting = JSON.parse(req.body.setting)
          console.log('setting--',setting, setting.onScreenNotification);
          if(setting.onScreenNotification === false || setting.onScreenNotification === true){
            console.log('setting onScreenNotification--', setting.onScreenNotification);

            Insuaranceform.setting.onScreenNotification = setting.onScreenNotification;
          }
          
          if(setting.inAppNotification === false || setting.inAppNotification === true){
            console.log('setting inAppNotification--', setting.inAppNotification);
            Insuaranceform.setting.inAppNotification = setting.inAppNotification;
          }

        }                      
        if(req.body.password!='' && typeof req.body.password !='undefined'){
          Insuaranceform.password = req.body.password;
        }
        if(req.body.handicap!='' && typeof req.body.handicap !='undefined'){
          Insuaranceform.handicap = req.body.handicap;
        }
        if(req.body.nickName!='' && typeof req.body.nickName !='undefined'){
          Insuaranceform.nickName = req.body.nickName;
        }
        
        if(typeof req.body.addressVerifiedToken !='undefined'){
          Insuaranceform.addressVerifiedToken = req.body.addressVerifiedToken;
        }

        Insuaranceform.role = req.body.role?req.body.role:Insuaranceform.role;
        Insuaranceform.pin = ( 
                              (req.body.pin === true || req.body.pin == 'true') || 
                              (req.body.pin === false || req.body.pin == 'false') 
                            ) ? req.body.pin:Insuaranceform.pin;
 
        let definedFriendList    = Insuaranceform.friendList ? Insuaranceform.friendList : []
            
        if(req.body.friendId != '' && req.body.friendId && !Insuaranceform.friendList.includes(req.body.friendId))
        {
          
            let unFriendIndex = Insuaranceform.unFriendList.indexOf(req.body.friendId);
            if (unFriendIndex !== -1) {
              Insuaranceform.unFriendList.splice(unFriendIndex, 1);
            }

            Insuaranceform.friendList = Insuaranceform.unFriendList
            
            definedFriendList.push(req.body.friendId)
            Insuaranceform.friendList = definedFriendList
        }
          
        let definedUnFriendList    = Insuaranceform.unFriendList ? Insuaranceform.unFriendList : []
            
        if(req.body.unFriendId != '' && req.body.unFriendId && !Insuaranceform.unFriendList.includes(req.body.unFriendId))
        {
          
            let friendIndex = Insuaranceform.friendList.indexOf(req.body.unFriendId);
            if (friendIndex !== -1) {
              Insuaranceform.friendList.splice(friendIndex, 1);
            }

            Insuaranceform.unFriendList = Insuaranceform.friendList

            definedUnFriendList.push(req.body.unFriendId)
            Insuaranceform.unFriendList = definedUnFriendList
        }

        if( req.files && req.files.photo)
        {
          console.log('')
         if(Insuaranceform.photo && Insuaranceform.photo!=''){
              InsuaranceformBusiness.unlinkFile(Insuaranceform.photo)
              .then( unlinkres => { console.log('unlinkres-',unlinkres)})
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
          }

          console.log('Insuaranceform.imageMediumPath--',Insuaranceform.imageMediumPath)

          if(Insuaranceform.imageMediumPath && Insuaranceform.imageMediumPath!=''){
            InsuaranceformBusiness.unlinkFile(Insuaranceform.imageMediumPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
          }

          if(Insuaranceform.imageThumbPath && Insuaranceform.imageThumbPath!=''){
            InsuaranceformBusiness.unlinkFile(Insuaranceform.imageThumbPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
          }
          
          Insuaranceform.imageType = config.imageType;
          let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
          Func(req.files.photo, req.Insuaranceform._id, 'Insuaranceforms', '/uploads/images/Insuaranceforms/', function(err, result) {
           
            if(result)
            {
            Insuaranceform.photo  = result.imageFullPath;
            Insuaranceform.imageMediumPath  = result.imageMediumPath;
            Insuaranceform.imageThumbPath  = result.imageThumbPath;

            InsuaranceformBusiness.update(Insuaranceform)
            .then((data) => {
              console.log('data',data)
             // handleResponse(res, 200, 'Insuaranceform Updated Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });

            }
          });

          InsuaranceformBusiness.update(Insuaranceform)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Insuaranceform Updated Successfully',true, data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message,false, err)
          });
          

        }else{
          if(Insuaranceform.photo){
            console.log('updated Insuaranceform---',Insuaranceform);
            InsuaranceformBusiness.update(Insuaranceform)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Insuaranceform Updated Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });

          }else{
            let Func = Uploader.uploadImageWithAvatar;
            Func({name:Insuaranceform.name,age:Insuaranceform.age}, Insuaranceform._id, 'Insuaranceforms', '/uploads/images/Insuaranceforms/', function(err, result) {
             console.log('result------>',result)
              if(result)
              {
                Insuaranceform.photo  = result.imageFullPath;
                Insuaranceform.imageMediumPath  = result.imageMediumPath;
                Insuaranceform.imageThumbPath  = result.imageThumbPath;
              }
              InsuaranceformBusiness.update(Insuaranceform)
              .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'Insuaranceform Updated Successfully',true, data)
              })
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
            });
          }


        }
         
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  /**
   * Deletes a Insuaranceform
   * restriction: 'admin'
   */
  static delete(req, res) {

    InsuaranceformValidator.validateUpdating(req.params).then(Insuaranceform => {

        InsuaranceformBusiness.findOne({_id: req.params.id})
        .then(Insuaranceform => {

            return InsuaranceformBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Insuaranceform Deleted Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }



}

module.exports = InsuaranceformController;
