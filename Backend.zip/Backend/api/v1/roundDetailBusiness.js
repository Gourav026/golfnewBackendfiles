var { RoundDetailSchema } =require('../schema/api')
var fs = require('fs')

class RoundDetailBusiness {
  /**
   * create a new roundDetail
   * @param  {Object} data roundDetail data
   * @return {Promise}
   */
  static create(data) {
    var newRoundDetail = new RoundDetailSchema(data);
    return newRoundDetail.save().then((roundDetail) => {
      //fire event to another sides
    console.log('roundDetail--->',roundDetail)
    return roundDetail
    });
  }

  /**
   * update roundDetail
   * @param  {Object} Mongoose roundDetail object
   * @return {Promise}
   */
  static update(roundDetail) {
    return roundDetail.save().then((updated) => {
     return updated
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data roundDetail data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of roundDetails
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 18;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }

    if(params.playerId){
      condition.playerId = new ObjectId(params.playerId) ;
    }

    if(params.roundId){
      condition.roundId = new ObjectId(params.roundId);
    }

    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       console.log('limit',limit)
       var aggregate = RoundDetailSchema.aggregate([
          {
              $match: condition
          },
          
          { 
              $lookup : {
                  from : 'rounds',
                  localField : 'roundId',
                  foreignField : '_id',
                  as : 'roundId'
              }
          },
          {
              $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
          },
          { 
            $lookup : {
                from : 'users',
                localField : 'scoreDetail.playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                holeNumber : 1,
                par:1,
                si:1,
                roundId:1,
                subTotal:1,
                playerScore:1,
                scoreDetail:1,
                result:1,
                updatedAt:1
            }
        }, 
        {
            $group : {              
                _id :"$_id",
                roundId : {
                  "$first": "$roundId"
                },
                holeNumber : {
                    "$first": "$holeNumber"
                },
                par : {
                    "$first": "$par"
                },
                si : {
                    "$first": "$si"
                },
                subTotal : {
                    "$first": "$subTotal"
                },
                scoreDetail : {
                    "$first": "$scoreDetail"
                },
                result : {
                    "$first": "$result"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                holeNumber : 1,
                roundId : 1,
                par:1,
                si:1,
                subTotal:1,
                scoreDetail: 1,
                result: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {holeNumber: 1}
        },
        { 
            '$facet'    : {
            metadata: [
               { $count: "total" },
               { $addFields: { page: page } },
               ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ], // add projection here wish you re-shape the docs
            resource: [
                      { 
                          $lookup : {
                              from : 'users',
                              localField : 'scoreDetail.playerId',
                              foreignField : '_id',
                              as : 'userId'
                          }
                      },
                      {
                          $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
                      },
                      {
                          $project : {
                              _id : 1,
                              subTotal:1,
                              userId: {
                                _id:"$userId._id",
                                firstName:"$userId.firstName",
                                lastName:"$userId.lastName",
                                photo:"$userId.photo"
                              }
                          }
                      },
                      {
                          $group : {              
                              _id :"$scoreDetail.playerId",
                              userId : {
                                "$addToSet": "$userId"
                             },
                             subTotal : {
                              "$addToSet": "$subTotal"
                           },
                          }
                      },
                      {
                        $addFields: {
                          total:{
                            parTotal: { $sum: "$subTotal.par" } ,
                            scoreTotal: { $sum: "$subTotal.score" } 
                          }
                        }
                      },
                      {
                          $project : {
                              _id : 1,
                              userId: 1,
                              subTotal:1,
                              total:1,
                          }
                      }
                    ]
          } 
        }
    ]

    ).exec()

    return aggregate
  }
  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return RoundDetailSchema.findOne(params).exec();
  }


  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return RoundDetailSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }

    /**
   * enter score details by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static enterScore(params) { 

    let promise =  new Promise( (resolve,reject) => { 

    let roundDetail = params.roundDetail
    let resultStatus =  {
      team        : 'A',      
      status      : ''  
    }
    if(params.round.startingHole != params.holeNumber )
    {
        let holeNumber = parseInt(params.holeNumber) - 1

        if(params.round.startingHole == 10 && holeNumber == 0)
        {
          holeNumber = 18
        }
         RoundDetailSchema.findOne({
              roundId: params.roundId,
              holeNumber: holeNumber,
            })
            .then(async roundPreviousDetail => {
                           
              params.previousScore.map( async (prevScore, i) => {  

                let parScore           = params.parTotal[params.holeNumber-1]
                let userScore          = prevScore.score
                let previousTeam       = "N/A"
                let previousStatus     = roundPreviousDetail.result.status
                let rounddetail        = await RoundDetailSchema.find({roundId:params.roundId})
                console.log('rounddetail--',rounddetail)

                let sumScore = 0
                let sumPar = 0
                console.log('sumPar--',sumPar)
                console.log('sumScore--',sumScore)

                let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status != 'E')
                //console.log('filteredRoundUP--',filteredRoundUP)
                console.log('previousStatus--',previousStatus)
                console.log('parScore--',parScore)

                let initNumber = 0
                let team = 'N/A'
                let status = 'E'
                if(filteredRoundUP.length > 0)
                {
                  team       = previousTeam
                  status     = previousStatus
                  if(status == 'E'){
                    initNumber = 0
                  }else{
                    initNumber = parseInt(previousStatus)
                  }
                }
                console.log('initNumber--',initNumber)
                console.log('parScore--',parScore)
                console.log('userScore--',userScore)

                if(params.round.startingHole == 10)
                {
                  if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                  {
                    sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    
                    sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                
                    roundDetail.subTotal    = { 
                                                title:'IN',
                                                par:sumPar,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
                  
                  if(parseInt(params.round.startingHole)-1 == params.holeNumber )
                  {
                    sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    
                    sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                
                    roundDetail.subTotal    = { 
                                                title:'OUT',
                                                par:sumPar,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
              }else{

                if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                {
                  sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  
                  sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                              
                  roundDetail.subTotal    = { 
                                              title:'OUT',
                                              par:sumPar,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }
                
                if(parseInt(params.round.startingHole)+17 == params.holeNumber )
                {
                  sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  
                  sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                              
                  roundDetail.subTotal    = { 
                                              title:'IN',
                                              par:sumPar,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }

              }

                  if(parScore > userScore)
                  {
                    console.log('result value 1-----',initNumber-parScore+userScore);

                    resultStatus =  {
                      team        : 'N/A',      
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber-parScore+userScore) >0 ? '+'+(initNumber-parScore+userScore) : (initNumber-parScore+userScore) : 'E'
                    }
                  }else if(parScore < userScore)
                  {
                    console.log('result value 2-----',initNumber-parScore+userScore);
                    resultStatus =  {
                      team        : 'N/A',      
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber+userScore-parScore) >0 ? '+'+(initNumber+userScore-parScore) : (initNumber+userScore-parScore) : 'E'
                    }
                  }else
                  {
                    console.log('result value 3-----',initNumber-parScore+userScore);

                    resultStatus =  {
                      team        : 'N/A',      
                      status      : status
                    }
                  }
                  
                roundDetail.par    = parScore                             
                roundDetail.result = resultStatus

                RoundDetailSchema.create(roundDetail)
                .then((data) => {
                  console.log('data',data)
                // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                  resolve(data)
                })
                .catch((err) => {
                  reject(err)

                }); 
                
                resolve(roundDetail)

                // handleResponse(res, 200, 'RoundDetail Added Successfully', {
                //   resultStatus:roundDetail })
              })
              .catch((err) => {
                reject(err)
              });
            })
            .catch((err) => {
              reject(err)

            }); 
            
    }else{
                
      let parScore  = params.parTotal[params.holeNumber-1]
      params.previousScore.map( async (prevScore, i) => {  
      
      console.log('prevScore--',prevScore, i);
      let userScore = prevScore.score
    
      console.log('parScore--->',parScore);
      console.log('userScore--->',userScore);
      if(parScore > userScore)
      {
        resultStatus =  {     
          status      : '-'+(parScore-userScore) 
        }
      }else if(parScore < userScore)
      {
        resultStatus =  { 
          status      : '+'+(userScore-parScore) 
        }
      }else
      {
        resultStatus =  { 
          status      : 'E' 
        }
      }
      roundDetail.result = resultStatus
      roundDetail.par    = parScore

      RoundDetailSchema.create(roundDetail)
      .then((data) => {
        console.log('data',data)
        resolve(data)

      // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
      })
      .catch((err) => {
        reject(err)

      //  handleResponse(res, 500, err.message, err)
      });    
      resolve(roundDetail)

      //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
      })

    }

    })
  return promise
  
  }

      /**
   * enter score details by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static enterScoreNext(params) { 

    let promise =  new Promise( (resolve,reject) => { 

    let roundDetail = params.roundDetail
    roundDetail.scoreDetail= []

    let resultStatus =  {
      team        : 'A',      
      status      : ''  
    }
    if(params.round.startingHole != params.holeNumber )
    {
        let holeNumber = parseInt(params.holeNumber) - 1

        if(params.round.startingHole == 10 && holeNumber == 0)
        {
          holeNumber = 18
        }
         RoundDetailSchema.findOne({
              roundId: params.roundId,
              holeNumber: holeNumber,
            })
            .then(async roundPreviousDetail => {
                           
              params.previousScore.map( async (prevScore, i) => {  

                let parScore           = params.parTotal[params.holeNumber-1]
                let userScore          = prevScore.score
                let previousTeam       = "N/A"
                let previousStatus     = roundPreviousDetail.result.status
                let rounddetail        = await RoundDetailSchema.find({roundId:params.roundId})
                console.log('rounddetail--',rounddetail)

                let sumScore = 0
                let sumPar = 0
                console.log('sumPar--',sumPar)
                console.log('sumScore--',sumScore)

                let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status != 'E')
                //console.log('filteredRoundUP--',filteredRoundUP)
                console.log('previousStatus--',previousStatus)
                console.log('parScore--',parScore)

                let initNumber = 0
                let team = 'N/A'
                let status = 'E'
                if(filteredRoundUP.length > 0)
                {
                  team       = previousTeam
                  status     = previousStatus
                  if(status == 'E'){
                    initNumber = 0
                  }else{
                    initNumber = parseInt(previousStatus)
                  }
                }
                console.log('initNumber--',initNumber)
                console.log('parScore--',parScore)
                console.log('userScore--',userScore)

                if(params.round.startingHole == 10)
                {
                  if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                  {
                    sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    
                    sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                
                    roundDetail.subTotal    = { 
                                                title:'IN',
                                                par:sumPar,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
                  
                  if(parseInt(params.round.startingHole)-1 == params.holeNumber )
                  {
                    sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    
                    sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                
                    roundDetail.subTotal    = { 
                                                title:'OUT',
                                                par:sumPar,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
              }else{

                if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                {
                  sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  
                  sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                              
                  roundDetail.subTotal    = { 
                                              title:'OUT',
                                              par:sumPar,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }
                
                if(parseInt(params.round.startingHole)+17 == params.holeNumber )
                {
                  sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  
                  sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                              
                  roundDetail.subTotal    = { 
                                              title:'IN',
                                              par:sumPar,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }

              }

                  if(parScore > userScore)
                  {
                    console.log('result value 1-----',initNumber-parScore+userScore);

                    resultStatus =  {   
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber-parScore+userScore) >0 ? '+'+(initNumber-parScore+userScore) : (initNumber-parScore+userScore) : 'E'
                    }
                  }else if(parScore < userScore)
                  {
                    console.log('result value 2-----',initNumber-parScore+userScore);
                    resultStatus =  {      
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber+userScore-parScore) >0 ? '+'+(initNumber+userScore-parScore) : (initNumber+userScore-parScore) : 'E'
                    }
                  }else
                  {
                    console.log('result value 3-----',initNumber-parScore+userScore);

                    resultStatus =  {    
                      status      : status
                    }
                  }
                  
                roundDetail.par    = parScore                             
                prevScore.result = resultStatus
                roundDetail.scoreDetail.push(prevScore)
                // RoundDetailSchema.create(roundDetail)
                // .then((data) => {
                //   console.log('data',data)
                // // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                //   resolve(data)
                // })
                // .catch((err) => {
                //   reject(err)

                // }); 
                
                resolve(roundDetail)

                // handleResponse(res, 200, 'RoundDetail Added Successfully', {
                //   resultStatus:roundDetail })
              })
              .catch((err) => {
                reject(err)
              });
            })
            .catch((err) => {
              reject(err)

            }); 
            
    }else{
                
      let parScore  = params.parTotal[params.holeNumber-1]
      let siScore   = params.siTotal[params.holeNumber-1]
      params.previousScore.map( async (prevScore, i) => {  
      
      console.log('prevScore--',prevScore, i);
      let userScore = prevScore.score
    
      console.log('parScore--->',parScore);
      console.log('userScore--->',userScore);
      if(parScore > userScore)
      {
        resultStatus =  {     
          status      : '-'+(parScore-userScore) 
        }
      }else if(parScore < userScore)
      {
        resultStatus =  { 
          status      : '+'+(userScore-parScore) 
        }
      }else
      {
        resultStatus =  { 
          status      : 'E' 
        }
      }
      prevScore.result = resultStatus
      roundDetail.scoreDetail.push(prevScore)
      roundDetail.par    = parScore
      roundDetail.si     = siScore

      // RoundDetailSchema.create(roundDetail)
      // .then((data) => {
      //   console.log('data',data)
      //   resolve(data)

      // // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
      // })
      // .catch((err) => {
      //   reject(err)

      // //  handleResponse(res, 500, err.message, err)
      // });    
      resolve(roundDetail)

      //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
      })

    }

    })
  return promise
  
  }

}

module.exports = RoundDetailBusiness;
