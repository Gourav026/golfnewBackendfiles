'use strict';

var { StateBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { StateValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class StateController {
  /**
   * Get list of states
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return StateBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'State List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new state
   */
  static create(req, res, next) {

    StateValidator.validateCreating(req.body).then(state => {
        state.name = req.body.name;
        state.countryId = req.body.countryId;
        state.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:true
             
        StateBusiness.create(state)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'State Added Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile State
   */
  static update(req, res, next) {
    //TODO - update validator
    StateValidator.validateUpdating({...req.body, ...req.params}).then(state => {
    console.log('req.files--->', req.files)
    var stateId = req.params.id;
    StateBusiness.findOne({_id: stateId})
      .then(state => {
        if (!state) { 
          handleResponse(res, 500, 'State Not Exist', {}) 
        }
        state.name = req.body.name?req.body.name:state.name;
        state.countryId = req.body.countryId?req.body.countryId:state.countryId;
        state.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:state.status;

          StateBusiness.update(state)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'State Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a state
   * restriction: 'admin'
   */
  static delete(req, res) {

    StateValidator.validateUpdating(req.params).then(state => {

        StateBusiness.findOne({_id: req.params.id})
        .then(state => {

            return StateBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'State deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = StateController;
