'use strict';
var { RoundDetailSchema, CourseDetailSchema, RoundSchema } = require('../../schema/api')
var { RoundDetailBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { RoundDetailValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')
var ObjectId = require('mongoose').Types.ObjectId;

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message||"Something Went Wrong",
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message||"Something Went Wrong",
        response:data
      });
}


class RoundDetailController {
  /**
   * Get list of roundDetails
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return RoundDetailBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'RoundDetail List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new roundDetail
   */
  static create(req, res, next) {

    RoundDetailValidator.validateCreating(req.body).then( roundDetail => {
            roundDetail.roundId     = req.body.roundId;
            roundDetail.holeNumber  = req.body.holeNumber;
            roundDetail.location    = req.body.location;
            roundDetail.scoreDetail = req.body.scoreDetail
            roundDetail.geoLocation = req.body.geoLocation?req.body.geoLocation:[];

            RoundDetailBusiness.findOne({
              roundId: req.body.roundId,
              holeNumber: req.body.holeNumber,
            })
            .then( async roundUpdatedDetail => {

              // if(req.body.modeSelection != 'strokemode')
              // {
              //   //status -- E , 1UP, 2UP, 3UP
              //   let resultStatus =  {
              //     team        : 'A',      
              //     status      : ''  
              //   }
              //   let previousScore = req.body.scoreDetail

              //   if(roundUpdatedDetail)
              //   {
              //      RoundDetailBusiness.findOne({
              //             roundId: req.body.roundId,
              //             holeNumber: parseInt(req.body.holeNumber)-1,
              //           })
              //           .then(async roundPreviousDetail => {
              //             let teamAScore         = previousScore.filter(team => team.team == 'A')[0].score
              //             let teamBScore         = previousScore.filter(team => team.team == 'B')[0].score

              //             if(previousScore.length > 2){

              //               teamAScore = previousScore.filter(team => team.team == 'A')
              //               teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
              //               teamBScore = previousScore.filter(team => team.team == 'B')
              //               teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)
  
              //             }

              //             let previousTeam       = roundPreviousDetail.result.team
              //             let previousStatus     = roundPreviousDetail.result.status
              //             let rounddetail        = await RoundDetailSchema.find({roundId:req.body.roundId})
              //             console.log('rounddetail--',rounddetail)

              //             let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status == '1UP')
              //             console.log('filteredRoundUP--',filteredRoundUP)
              //             console.log('previousStatus--',previousStatus)

              //             let initNumber = 1
              //             let team = 'N/A'
              //             let status = 'AS'
              //             if(filteredRoundUP.length > 0)
              //             {
              //                team       = previousTeam
              //                status     = previousStatus
              //                if(status == 'AS'){
              //                 initNumber = 1
              //                }else{
              //                 initNumber = parseInt(previousStatus.charAt(0)) +1
              //                }
              //               //  console.log('team--',team)
              //               //  console.log('status--',status)
                            
              //             }
                          

              //         // console.log('teamAScore--->',teamAScore);
              //         // console.log('teamBScore--->',teamBScore);

              //             if(teamAScore > teamBScore)
              //             {
              //               if(previousTeam == 'A')
              //               {
              //                 team = 'A'
              //                 initNumber = parseInt(previousStatus.charAt(0))-1
              //               }else{
              //                 team = 'B'
              //               }
              //             //  console.log('initNumber--->',initNumber);


              //               if(initNumber == 0){

              //                 resultStatus =  {
              //                   team        : 'N/A',      
              //                   status      : 'AS' 
              //                 }

              //               }else{

              //                 resultStatus =  {
              //                   team        : team,      
              //                   status      : initNumber+'UP' 
              //                 }

              //               }
              //               console.log('resultStatus 1. --->',resultStatus );


              //             }else if(teamAScore < teamBScore)
              //             {
              //               if(previousTeam == 'B')
              //               {
              //                 team = 'B'
              //                 initNumber = parseInt(previousStatus.charAt(0))-1
              //               }else{
              //                 team = 'A'
              //               }

              //               if(initNumber == 0){

              //                 resultStatus =  {
              //                   team        : 'N/A',      
              //                   status      : 'AS' 
              //                 }

              //               }else{

              //                 resultStatus =  {
              //                   team        : team,      
              //                   status      : initNumber+'UP' 
              //                 }

              //               }
                            
              //             }else
              //             {
              //               resultStatus =  {
              //                 team        : team,      
              //                 status      : status
              //               }
              //             }

              //             roundDetail.result = resultStatus

              //             RoundDetailBusiness.create(roundDetail)
              //             .then((data) => {
              //               console.log('data',data)
              //               handleResponse(res, 200, 'RoundDetail Added Successfully', data)
              //             })
              //             .catch((err) => {
              //               handleResponse(res, 500, err.message, err)
              //             });                                      
              //             // handleResponse(res, 200, 'RoundDetail Added Successfully', {
              //             //   resultStatus:resultStatus })
              //           })
              //           .catch((err) => {
              //             handleResponse(res, 500, err.message, err)
              //           });
                                 
              //   }else{
                    
              //         let teamAScore = previousScore.filter(team => team.team == 'A')[0].score
              //         let teamBScore = previousScore.filter(team => team.team == 'B')[0].score
                      
              //         if(previousScore.length > 2){

              //           teamAScore = previousScore.filter(team => team.team == 'A')
              //           teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
              //           teamBScore = previousScore.filter(team => team.team == 'B')
              //           teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)

              //         }

              //         console.log('teamAScore--->',teamAScore);
              //         console.log('teamBScore--->',teamBScore);
              //         if(teamAScore > teamBScore)
              //         {
              //           resultStatus =  {
              //             team        : 'B',      
              //             status      : 1+'UP' 
              //           }
              //         }else if(teamAScore < teamBScore)
              //         {
              //           resultStatus =  {
              //             team        : 'A',      
              //             status      : 1+'UP' 
              //           }
              //         }else
              //         {
              //           resultStatus =  {
              //             team        : 'N/A',      
              //             status      : 'AS' 
              //           }
              //         }

              //         roundDetail.result = resultStatus

              //         RoundDetailBusiness.create(roundDetail)
              //       .then((data) => {
              //         console.log('data',data)
              //         handleResponse(res, 200, 'RoundDetail Added Successfully', data)
              //       })
              //       .catch((err) => {
              //         handleResponse(res, 500, err.message, err)
              //       });                        
              //       //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
                  
              //   }

              // }else{
         
            
                let previousScore = req.body.scoreDetail
                
                let round               = await RoundSchema.findOne({_id:new ObjectId(req.body.roundId)})
                console.log('round--',round)
                let coursedetail        = await CourseDetailSchema.find({courseId:round.courseId}).sort({holeNumber:1})
                console.log('coursedetail--',coursedetail)
                let parTotal = coursedetail.map( (crsdetail) => {
                  return crsdetail.par
                })
                
                let siTotal = coursedetail.map( (crsdetail) => {
                  return crsdetail.strokeIndex
                })
                console.log('siTotal-------',siTotal);
                /** for stroke play */


                RoundDetailBusiness.enterScoreNext({
                  roundDetail         : roundDetail,
                  previousScore       : previousScore,
                  parTotal            : parTotal,
                  siTotal             : siTotal,
                  roundId             : req.body.roundId,
                  holeNumber          : req.body.holeNumber,
                  round               : round
                })
                .then( data => {
                     console.log('data round detail----->',data)

                      RoundDetailSchema.create(data)
                          .then((roundData) => {
                            console.log('roundData',roundData)
                            handleResponse(res, 200, 'RoundDetail Added Successfully', roundData)
                          })
                          .catch((err) => {
                            handleResponse(res, 500, err.message, err)

                          }); 
                    // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                  })
                  .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                  }); 

              
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


    /**
   * Creates a new roundDetail
   */
  static createnext(req, res, next) {

    RoundDetailValidator.validateCreating(req.body).then( roundDetail => {
            roundDetail.roundId     = req.body.roundId;
            roundDetail.holeNumber  = req.body.holeNumber;
            roundDetail.scoreDetail = req.body.scoreDetail

            RoundDetailBusiness.findOne({
              roundId: req.body.roundId,
              holeNumber: req.body.holeNumber,
            })
            .then( async roundUpdatedDetail => {

              if(req.body.modeSelection != 'strokemode')
              {
                //status -- E , 1UP, 2UP, 3UP
                let resultStatus =  {
                  team        : 'A',      
                  status      : ''  
                }
                let previousScore = req.body.scoreDetail

                if(roundUpdatedDetail)
                {
                   RoundDetailBusiness.findOne({
                          roundId: req.body.roundId,
                          holeNumber: parseInt(req.body.holeNumber)-1,
                        })
                        .then(async roundPreviousDetail => {
                          let teamAScore         = previousScore.filter(team => team.team == 'A')[0].score
                          let teamBScore         = previousScore.filter(team => team.team == 'B')[0].score

                          if(previousScore.length > 2){

                            teamAScore = previousScore.filter(team => team.team == 'A')
                            teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
                            teamBScore = previousScore.filter(team => team.team == 'B')
                            teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)
  
                          }

                          let previousTeam       = roundPreviousDetail.result.team
                          let previousStatus     = roundPreviousDetail.result.status
                          let rounddetail        = await RoundDetailSchema.find({roundId:req.body.roundId})
                          console.log('rounddetail--',rounddetail)

                          let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status == '1UP')
                          console.log('filteredRoundUP--',filteredRoundUP)
                          console.log('previousStatus--',previousStatus)

                          let initNumber = 1
                          let team = 'N/A'
                          let status = 'AS'
                          if(filteredRoundUP.length > 0)
                          {
                             team       = previousTeam
                             status     = previousStatus
                             if(status == 'AS'){
                              initNumber = 1
                             }else{
                              initNumber = parseInt(previousStatus.charAt(0)) +1
                             }
                            //  console.log('team--',team)
                            //  console.log('status--',status)
                            
                          }
                          

                      // console.log('teamAScore--->',teamAScore);
                      // console.log('teamBScore--->',teamBScore);

                          if(teamAScore > teamBScore)
                          {
                            if(previousTeam == 'A')
                            {
                              team = 'A'
                              initNumber = parseInt(previousStatus.charAt(0))-1
                            }else{
                              team = 'B'
                            }
                          //  console.log('initNumber--->',initNumber);


                            if(initNumber == 0){

                              resultStatus =  {
                                team        : 'N/A',      
                                status      : 'AS' 
                              }

                            }else{

                              resultStatus =  {
                                team        : team,      
                                status      : initNumber+'UP' 
                              }

                            }
                            console.log('resultStatus 1. --->',resultStatus );


                          }else if(teamAScore < teamBScore)
                          {
                            if(previousTeam == 'B')
                            {
                              team = 'B'
                              initNumber = parseInt(previousStatus.charAt(0))-1
                            }else{
                              team = 'A'
                            }

                            if(initNumber == 0){

                              resultStatus =  {
                                team        : 'N/A',      
                                status      : 'AS' 
                              }

                            }else{

                              resultStatus =  {
                                team        : team,      
                                status      : initNumber+'UP' 
                              }

                            }
                            
                          }else
                          {
                            resultStatus =  {
                              team        : team,      
                              status      : status
                            }
                          }

                          roundDetail.result = resultStatus

                          RoundDetailBusiness.create(roundDetail)
                          .then((data) => {
                            console.log('data',data)
                            handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                          })
                          .catch((err) => {
                            handleResponse(res, 500, err.message, err)
                          });                                      
                          // handleResponse(res, 200, 'RoundDetail Added Successfully', {
                          //   resultStatus:resultStatus })
                        })
                        .catch((err) => {
                          handleResponse(res, 500, err.message, err)
                        });
                                 
                }else{
                    
                      let teamAScore = previousScore.filter(team => team.team == 'A')[0].score
                      let teamBScore = previousScore.filter(team => team.team == 'B')[0].score
                      
                      if(previousScore.length > 2){

                        teamAScore = previousScore.filter(team => team.team == 'A')
                        teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
                        teamBScore = previousScore.filter(team => team.team == 'B')
                        teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)

                      }

                      console.log('teamAScore--->',teamAScore);
                      console.log('teamBScore--->',teamBScore);
                      if(teamAScore > teamBScore)
                      {
                        resultStatus =  {
                          team        : 'B',      
                          status      : 1+'UP' 
                        }
                      }else if(teamAScore < teamBScore)
                      {
                        resultStatus =  {
                          team        : 'A',      
                          status      : 1+'UP' 
                        }
                      }else
                      {
                        resultStatus =  {
                          team        : 'N/A',      
                          status      : 'AS' 
                        }
                      }

                      roundDetail.result = resultStatus

                      RoundDetailBusiness.create(roundDetail)
                    .then((data) => {
                      console.log('data',data)
                      handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                    })
                    .catch((err) => {
                      handleResponse(res, 500, err.message, err)
                    });                        
                    //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
                  
                }

              }else{
            
                let previousScore = req.body.scoreDetail
                
                let round               = await RoundSchema.findOne({_id:new ObjectId(req.body.roundId)})
                console.log('round--',round)
                let coursedetail        = await CourseDetailSchema.find({courseId:round.courseId}).sort({holeNumber:1})
                console.log('coursedetail--',coursedetail)
                let parTotal = coursedetail.map( (crsdetail) => {
                  return crsdetail.par
                })
                
                let siTotal = coursedetail.map( (crsdetail) => {
                  return crsdetail.strokeIndex
                })
                console.log('siTotal-------',siTotal);
                /** for stroke play */


                RoundDetailBusiness.enterScoreNext({
                  roundDetail         : roundDetail,
                  previousScore       : previousScore,
                  parTotal            : parTotal,
                  siTotal             : siTotal,
                  roundId             : req.body.roundId,
                  holeNumber          : req.body.holeNumber,
                  round               : round
                })
                .then( data => {
                     console.log('data round detail----->',data)

                      RoundDetailSchema.create(data)
                          .then((roundData) => {
                            console.log('roundData',roundData)
                            handleResponse(res, 200, 'RoundDetail Added Successfully', roundData)
                          })
                          .catch((err) => {
                            handleResponse(res, 500, err.message, err)

                          }); 
                    // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                  })
                  .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                  }); 

              }
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

   /**
   * Update Profile RoundDetail
   */
  static update(req, res, next) {
    //TODO - update validator
    RoundDetailValidator.validateUpdating({...req.body, ...req.params}).then(roundDetail => {
    console.log('req.files--->', req.files)
    var roundDetailId = req.params.id;
    RoundDetailBusiness.findOne({_id: roundDetailId})
      .then(async roundDetail => {
          if (!roundDetail) { 
            handleResponse(res, 500, 'RoundDetail Not Exist', {}) 
          }

          roundDetail.roundId = req.body.roundId?req.body.roundId:roundDetail.roundId;
          roundDetail.holeNumber = req.body.holeNumber?req.body.holeNumber:roundDetail.holeNumber;
          roundDetail.par = req.body.par?req.body.par:roundDetail.par;
          roundDetail.geoLocation = req.body.geoLocation?req.body.geoLocation:roundDetail.geoLocation;


          if(req.body.scoreDetail || req.body.location)
          {
             let scoreDetail = req.body.scoreDetail?req.body.scoreDetail:roundDetail.scoreDetail
             let location    = req.body.location   ?req.body.location   :roundDetail.location
                  
             let minScore =  scoreDetail.sort(function (a, b) {
                return a.score - b.score
              })
              
              minScore = minScore[0]
              console.log('minScore--->', minScore)
              
              scoreDetail = scoreDetail.map((sd)=>{
               // console.log('sd---------------',sd)
                let filterAllEqual = scoreDetail.filter(val => val.score == minScore.score) 
                console.log('filterAllEqual---------------',filterAllEqual.length)
                console.log('scoreDetail.length---------------',scoreDetail.length)
                
                if(sd && sd.score)
                {
                  sd.score = sd.score>18 ? null : sd.score
                  if(filterAllEqual.length != scoreDetail.length)
                  {
                    sd.highlight = sd.score == minScore.score ? true : false
                  }
                }
                return sd
              })
              let round           = await RoundSchema.findOne({_id:new ObjectId(roundDetail.roundId)})
              //console.log('round--',round)

              
              let coursedetail  = await CourseDetailSchema.find({courseId:round.courseId}).sort({holeNumber:1})
              //console.log('coursedetail--',coursedetail)

              let parTotal      = coursedetail.map( (crsdetail) => {
                return crsdetail.par
              })
              
              let siTotal       = coursedetail.map( (crsdetail) => {
                return crsdetail.strokeIndex
              })

              //console.log('siTotal-------',siTotal);

              await RoundDetailSchema.updateOne({_id: roundDetailId}, {
                $set: {
                    "scoreDetail": scoreDetail,
                    "location": location
                }           
              });

              let totalRoundDetail = await RoundDetailSchema.find({roundId:new ObjectId(roundDetail.roundId)})
              //console.log('totalRoundDetail--',totalRoundDetail)
              
              // let scoreStatus = await RoundDetailBusiness.getPlayerScoreStatus({
              //   totalRoundDetail    : totalRoundDetail,
              //   roundDetail         : roundDetail,
              //   previousScore       : previousScore,
              //   parTotal            : parTotal,
              //   siTotal             : siTotal,
              //   roundId             : roundDetail.roundId,
              //   holeNumber          : roundDetail.holeNumber,
              //   round               : round
              // })


              totalRoundDetail =  totalRoundDetail.map( val => 
                { 
                  //let validPlayers = val.scoreDetail.filter( score.isEditable !=false)
      
                  let filterVal = val.scoreDetail.filter( score => score.score !=null)
                  return filterVal 
                }).filter( rdetail => rdetail !='')
              
              //console.log('totalRoundDetail--',totalRoundDetail) 
              let lastUpdatedHole = totalRoundDetail.length -1 +round.startingHole
              console.log('lastUpdatedHole--',lastUpdatedHole) 
              console.log('round.startingHole--',round.startingHole) 

              if(lastUpdatedHole >= 18 && round.startingHole === 10)
              {
                console.log('ENTER--',round.startingHole) 

                lastUpdatedHole = totalRoundDetail.length -1 - round.startingHole +2
              }
              await RoundSchema.updateOne( {_id: roundDetail.roundId }, {
                $set: {
                    "lastUpdatedHole": lastUpdatedHole
                  }           
              }); 

              // await RoundDetailSchema.updateOne({_id: roundDetailId}, {
              //   $set: {
              //       "result"     : scoreStatus
              //   }           
              // });              
              //console.log('scorestatus--->',scoreStatus);

          }
        
          RoundDetailBusiness.findOne({_id: roundDetailId})
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'RoundDetail Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a roundDetail
   * restriction: 'admin'
   */
  static delete(req, res) {

    RoundDetailValidator.validateUpdating(req.params).then(roundDetail => {

        RoundDetailBusiness.findOne({_id: req.params.id})
        .then(roundDetail => {

            return RoundDetailBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'RoundDetail deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = RoundDetailController;
