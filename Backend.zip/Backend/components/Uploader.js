'use strict';

var async = require('async')
var fs = require('fs')
var path = require('path')
var GM = require('./GM')
var gm =require('gm')
var AWSS3 = require('./AWSS3')
var Queue = require('./Queue')
var TmpFile = require('../schema/api')
var StringHelper = require('../helpers/StringHelper')
var config = require('../config/environment')
var { UtilsHelper } = require('../helpers')
var mv = require('mv');
const Jimp = require('jimp');
var ffmpeg =require('fluent-ffmpeg')
var https = require('https');


class Uploader {

  static uploadImageWithThumbnails(file, id, module, destination, cb){
    console.log('id uploader--',id,file)

    if (!file) {
    console.log('id uploader--',file)

      return cb(null,null);
    }
    var date = new Date();
    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt(file.name || file.filename);

    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var tempPath = file.path;
    var dir = path.join(config.imageTempFolder + "/" + module + "/" + id);
    //Set size image
    var imageSmallSize = config.imageSmallSize;
    var imageMediumSize = config.imageMediumSize;
    //Set image resize name
    var imageSmallName = "resize_" + imageSmallSize.width + "x" + imageSmallSize.height + "_" + fileName;
    var imageMediumName = "resize_" + imageMediumSize.width + "x" + imageMediumSize.height + "_" + fileName;
    //Set Path destinational
    var imageThumbPath =  dir +"/" + imageSmallName;
    var imageMediumPath =  dir +"/" + imageMediumName;
    //Setup Option resize
    var gmSmallOptions = { width: imageSmallSize.width, height: imageSmallSize.height, dest:imageThumbPath };
    var gmMediumOptions = { width: imageMediumSize.width, height: imageMediumSize.height, dest:imageMediumPath };
    console.log('dir--',dir)

    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }

    var fileFullPath = dir + "/" + fileName;
    console.log('fileFullPath--',fileFullPath)

    async.auto({
      imageFullPath: function(callback){
        file.mv(fileFullPath, function(err) {
          console.log('error--',err)
          if (err) {
            return cb(err);
          }
          console.log('fileFullPath--',fileFullPath)
          //return destination + id + "/" + fileName
          callback(null, destination + id + "/" + fileName);
        });
      },
      imageThumbPath:  function(callback){
        Jimp.read(fileFullPath)
            .then(lenna => {
               lenna
                .resize(imageSmallSize.width, imageSmallSize.height) // resize
                .quality(60) // set JPEG quality
                .write(imageThumbPath); // save
                //return destination + id + "/" + imageSmallName

                callback(null, destination + id + "/"+imageSmallName);

            })
            .catch(err => {
              console.error(err);
            });
      
      },
      imageMediumPath:  function(callback){
          Jimp.read(fileFullPath)
          .then(lenna => {
            lenna
              .resize(imageMediumSize.width, imageMediumSize.height) // resize
              .quality(60) // set JPEG quality
              .write(imageMediumPath); // save
              //return destination + id + "/" + imageMediumName

             callback(null, destination + id + "/"+imageMediumName);

          })
          .catch(err => {
            console.error(err);
          });
      }
    }, function(err, result){
      console.log('result---',result)
      cb(err, result);
    });
  }


  static uploadImageWithSocialMedia(file, id, module, destination, cb){
    console.log('id uploader--',id,file)

    if (!file) {
    console.log('id uploader--',file)

      return cb(null,null);
    }
    var date = new Date();
    var newFileName =
      StringHelper.randomString(7) + '.png';

    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var dir = path.join(config.imageTempFolder + "/" + module + "/" + id);
    //Set size image
    var imageSmallSize = config.imageSmallSize;
    var imageMediumSize = config.imageMediumSize;
    //Set image resize name
    var imageSmallName = "resize_" + imageSmallSize.width + "x" + imageSmallSize.height + "_" + fileName;
    var imageMediumName = "resize_" + imageMediumSize.width + "x" + imageMediumSize.height + "_" + fileName;
    //Set Path destinational
    var imageThumbPath =  dir +"/" + imageSmallName;
    var imageMediumPath =  dir +"/" + imageMediumName;
    //Setup Option resize
    var gmSmallOptions = { width: imageSmallSize.width, height: imageSmallSize.height, dest:imageThumbPath };
    var gmMediumOptions = { width: imageMediumSize.width, height: imageMediumSize.height, dest:imageMediumPath };
    console.log('dir--',dir)

    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }

    var fileFullPath = dir + "/" + fileName;
    console.log('fileFullPath--',fileFullPath)

    async.auto({
      imageFullPath: function(callback){

        new Promise((resolve, reject) => {
            https.get(file, (res) => {
                if (res.statusCode !== 200) {
                    var err = new Error('File couldn\'t be retrieved');
                    err.status = res.statusCode;
                    return reject(err);
                }
                var chunks = [];
                res.setEncoding('binary');
                res.on('data', (chunk) => {
                    chunks += chunk;
                }).on('end', () => {
                    var stream = fs.createWriteStream(fileFullPath);
                    stream.write(chunks, 'binary');
                    stream.on('finish', () => {
                      resolve('File Saved !');

                    });
                    res.pipe(stream);
                })
            }).on('error', (e) => {
                console.log("Error:----> " + e);
               // reject(e.message);
            });
      }).then( (all_result)=>{
        console.log('all_result',all_result);

        callback(null, destination + id + "/" + fileName);
      })


      },
      imageThumbPath:  function(callback){

        callback(null, destination + id + "/" + fileName);      
      
      },
      imageMediumPath:  function(callback){
        
        callback(null, destination + id + "/" + fileName);

      }
    }, function(err, result){
      console.log('result---',result)
      cb(err, result);
    });
  }


  static uploadImageWithAvatar(file, id, module, destination, cb){
    console.log('id uploader--',id,file)
    
    let rawdata = fs.readFileSync(path.join(config.utilsFolder + "/increment.json"));
    let incrementedData = JSON.parse(rawdata);
    console.log('incrementedData--->',incrementedData);
    let increment = incrementedData.increment
    
    let colorArray = ['#9400D3','#4B0082','#0000FF','#00FF00','#FFFF00','#FF7F00','#FF0000']
    let colorIndex = colorArray[increment]

    if([6].includes(increment)){
      increment = 0
    }else{
      increment++
    }

    let updatedData = JSON.stringify({increment:increment});
    fs.writeFileSync(path.join(config.utilsFolder + "/increment.json"), updatedData);

    if (!file) {
    console.log('id uploader--',file)

      return cb(null,null);
    }
    var date = new Date();
    var newFileName =
      StringHelper.randomString(7) + '.png';

    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var dir = path.join(config.imageTempFolder + "/" + module + "/" + id);
    var defaultImage = path.join(config.imageTempFolder + "/default.png");
    //Set size image
    var imageSmallSize = config.imageSmallSize;
    var imageMediumSize = config.imageMediumSize;
    //Set image resize name
    var imageSmallName = "resize_" + imageSmallSize.width + "x" + imageSmallSize.height + "_" + fileName;
    var imageMediumName = "resize_" + imageMediumSize.width + "x" + imageMediumSize.height + "_" + fileName;
    //Set Path destinational
    var imageThumbPath =  dir +"/" + imageSmallName;
    var imageMediumPath =  dir +"/" + imageMediumName;
    //Setup Option resize
    var gmSmallOptions = { width: imageSmallSize.width, height: imageSmallSize.height, dest:imageThumbPath };
    var gmMediumOptions = { width: imageMediumSize.width, height: imageMediumSize.height, dest:imageMediumPath };
    console.log('dir--',dir)

    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }

    var fileFullPath = dir + "/" + fileName;
    console.log('fileFullPath--',fileFullPath)
    let avatar = '??'
    if(file.firstName =='Unknown')
    {
      avatar = file.firstName.charAt(0).toUpperCase()   + 'NK'
    }
    else if(file.firstName && file.lastName)
    {
      avatar = file.firstName.charAt(0).toUpperCase()  + file.lastName.charAt(0).toUpperCase() 
    }else{
      avatar = file.firstName.charAt(0).toUpperCase()
    }

    async.auto({
      imageFullPath: function(callback){
        gm(defaultImage)
        .stroke("#FFFFFF")
        .crop(0.5,0.5)
        .background(colorIndex)
        .extent(340,300)
        .gravity('Center')
        .fill("#FFFFFF")
        .fontSize(160)
        .drawText(0, 0, avatar)
        .write(fileFullPath, function (err) { 
          if (!err){
            console.log('error------>',err);
          }
          console.log('done');
          callback(null, destination + id + "/" + fileName);
        });
      },
      imageThumbPath:  function(callback){

        gm(defaultImage)
        .stroke("#FFFFFF")
        .crop(0.5,0.5)
        .background(colorIndex)
        .extent(340,300)
        .gravity('Center')
        .fill("#FFFFFF")
        .fontSize(160)
        .drawText(0, 0, avatar)
        .resize(imageSmallSize.width, imageSmallSize.height, '^')
        .write(imageThumbPath, function (err) { 
          if (!err){
            console.log('error------>',err);
          }
          console.log('done');
          callback(null, destination + id + "/" + imageSmallName);
        });        
      
      },
      imageMediumPath:  function(callback){

        gm(defaultImage)
        .stroke("#FFFFFF")
        .crop(0.5,0.5)
        .background(colorIndex)
        .extent(340,300)
        .gravity('Center')
        .fill("#FFFFFF")
        .fontSize(160)
        .drawText(0, 0, avatar)
        .resize(imageMediumSize.width, imageMediumSize.height, '^')
        .write(imageMediumPath, function (err) { 
          if (!err){
            console.log('error------>',err);
          }
          console.log('done');
          callback(null, destination + id + "/" + imageMediumName);
        });        

      }
    }, function(err, result){
      console.log('result---',result)
      cb(err, result);
    });
  }

  static uploadImageWithBase64(file, id, module, destination, cb){
    console.log('id uploader--',id,file)

    if (!file) {
    console.log('id uploader--',file)

      return cb(null,null);
    }
    var date = new Date();
    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt('test.jpg');

    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    //var tempPath = file.path;
    var dir = path.join(config.imageTempFolder + "/" + module + "/" + id);
    //Set size image
    var imageSmallSize = config.imageSmallSize;
    var imageMediumSize = config.imageMediumSize;
    //Set image resize name
    var imageSmallName = "resize_" + imageSmallSize.width + "x" + imageSmallSize.height + "_" + fileName;
    var imageMediumName = "resize_" + imageMediumSize.width + "x" + imageMediumSize.height + "_" + fileName;
    //Set Path destinational
    var imageThumbPath =  dir +"/" + imageSmallName;
    var imageMediumPath =  dir +"/" + imageMediumName;
    //Setup Option resize
    var gmSmallOptions = { width: imageSmallSize.width, height: imageSmallSize.height, dest:imageThumbPath };
    var gmMediumOptions = { width: imageMediumSize.width, height: imageMediumSize.height, dest:imageMediumPath };
    console.log('dir--',dir)

    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }

    var fileFullPath = dir + "/" + fileName;
    console.log('fileFullPath--',fileFullPath)
    // Base64 string
    // Convert base64 to buffer => <Buffer ff d8 ff db 00 43 00 ...
    const buffer = Buffer.from(file, "base64");

    async.auto({
      imageFullPath: function(callback){
        Jimp.read(buffer)
        .then(lenna => {
           lenna
            .quality(60) // set JPEG quality
            .write(fileFullPath); // save
            //return destination + id + "/" + imageSmallName
            callback(null, destination + id + "/"+fileName);

        })
        .catch(err => {
          console.error(err);
        });
      },
      imageThumbPath:  function(callback){
        Jimp.read(buffer)
            .then(lenna => {
               lenna
                .resize(imageSmallSize.width, imageSmallSize.height) // resize
                .quality(60) // set JPEG quality
                .write(imageThumbPath); // save
                //return destination + id + "/" + imageSmallName

                callback(null, destination + id + "/"+imageSmallName);

            })
            .catch(err => {
              console.error(err);
            });
      
      },
      imageMediumPath:  function(callback){
          Jimp.read(buffer)
          .then(lenna => {
            lenna
              .resize(imageMediumSize.width, imageMediumSize.height) // resize
              .quality(60) // set JPEG quality
              .write(imageMediumPath); // save
              //return destination + id + "/" + imageMediumName

             callback(null, destination + id + "/"+imageMediumName);

          })
          .catch(err => {
            console.error(err);
          });
      }
    }, function(err, result){
      console.log('result---',result)
      cb(err, result);
    });
  }

  
  static uploadImage(file, id, cb){
    if (!file) {
      return cb();
    }

    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt(file.name || file.filename);
    var date = new Date();
    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var dir = path.join(config.imageTempFolder + "/users/" + id);
    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }
    file.mv(dir +"/"+fileName, (err, data) => {
      if (err) {
        return cb(err);
      }
      cb(null, "/uploads/images/users/"+id+"/"+fileName);
    });
  }

  static uploadImageToS3(file, id, cb){
    if (!file) {
      return cb();
    }
    var date = new Date();
    var fileName = date.getFullYear().toString() + (date.getMonth()+1).toString()
      + date.getDate().toString() + date.getHours().toString()
      + date.getMinutes().toString() + date.getSeconds().toString()
      + "_" +file.name;
    var dir = path.join(config.imageTempFolder + "/users/" + id);
    if (!fs.existsSync(dir)){
      UtilsHelper.mkdirpSync(dir,'0777');
    }

    let filePath = dir +"/"+fileName;
    file.mv(file.path, filePath, function(err, data) {
      if (err) {
        return cb(err);
      }

      Queue.create('UPLOAD_S3', {
        filePath: filePath,
        fileName: fileName,
        ACL: 'public-read',
        contentType: 'image/png'
      })
      .save(() => {
        TmpFile.create({
          filePath: filePath
        });
        cb(null, AWSS3.getPublicUrl(fileName));
      });
    });
  }

  //TODO - should convert mp4 file?
  static uploadFile(file, cb) {
    if (!file) {
      return cb();
    }
    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt(file.name || file.filename);
    var date = new Date();
    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var dir = path.join(config.fileTempFolder);
    if (!fs.existsSync(dir)) {
      UtilsHelper.mkdirpSync(dir,'0777');
    }
    file.mv( dir +"/"+fileName, function(err) {
      if (err) {
        return cb(err);
      }

      cb(null, "/uploads/files/" + fileName);
    });
  }

  static uploadFileS3(file, cb) {
    if (!file) {
      return cb();
    }

    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt(file.name || file.filename);
    var date = new Date();
    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var dir = path.join(config.fileTempFolder);
    if (!fs.existsSync(dir)) {
      UtilsHelper.mkdirpSync(dir,'0777');
    }
    var filePath = dir +"/"+fileName;
    file.mv( dir +"/"+fileName, function(err) {
      if (err) {
        return cb(err);
      }

      Queue.create('UPLOAD_S3', {
        filePath: filePath,
        fileName: fileName,
        ACL:'public-read',
        contentType: StringHelper.getContentType(StringHelper.getExt(fileName))
      })
      .save(() => cb(null, AWSS3.getPublicUrl(fileName)));
    });
  }

  static uploadImageWithThumbnailsToS3(file, id, cb) {
    console.log('id uploader s3--',id,file)

    if (!file) {
      return cb();
    }

    var newFileName =
      StringHelper.randomString(7) +
      StringHelper.getExt(file.name || file.filename);
    var date = new Date();
    var fileName =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString() +
      date.getDate().toString() +
      date.getHours().toString() +
      date.getMinutes().toString() +
      date.getSeconds().toString() +
      "_" +
      newFileName;
    var tempPath = file.path;
    var dir = path.join(config.imageTempFolder + "/users/" + id);

    if (!fs.existsSync(dir)) {
      UtilsHelper.mkdirpSync(dir, '0777');
    }

    //Set size image
    var imageSmallSize = config.imageSmallSize;
    var imageMediumSize = config.imageMediumSize;
    //Set image resize name
    var imageSmallName = "resize_" + imageSmallSize.width + "x" + imageSmallSize.height + "_" + fileName;
    var imageMediumName = "resize_" + imageMediumSize.width + "x" + imageMediumSize.height + "_" + fileName;
    //Set Path destinational
    var imageThumbPath =  dir +"/" + imageSmallName;
    var imageMediumPath =  dir +"/" + imageMediumName;
    //Setup Option resize
    var gmSmallOptions = { width: imageSmallSize.width, height: imageSmallSize.height, dest:imageThumbPath };
    var gmMediumOptions = { width: imageMediumSize.width, height: imageMediumSize.height, dest:imageMediumPath };

    async.auto({
      imageFullPath: function(cb) {
        Queue.create('UPLOAD_S3', {
          filePath: tempPath,
          fileName: fileName,
          ACL: 'public-read',
          contentType: 'image/png'
        })
        .save(() => {
          TmpFile.create({
            filePath: tempPath
          });
          cb(null, AWSS3.getPublicUrl(fileName));
        });
      },
      imageThumbPath: function(cb) {
        GM.resize(tempPath, gmSmallOptions, (err, data) => {
          if (err) {
            return cb();
          }
          Queue.create('UPLOAD_S3', {
            filePath: data.path,
            fileName: imageSmallName,
            ACL: 'public-read',
            contentType: 'image/png'
          })
          .save(() => {
            TmpFile.create({
              filePath: data.path
            });
            cb(null, AWSS3.getPublicUrl(imageSmallName));
          });
        });
      },
      imageMediumPath: function(cb) {
        GM.resize(tempPath, gmMediumOptions, (err, data) => {
          if (err) {
            return cb();
          }
          Queue.create('UPLOAD_S3', {
            filePath: data.path,
            fileName: imageMediumName,
            ACL: 'public-read',
            contentType: 'image/png'
          })
          .save(() => {
            TmpFile.create({
              filePath: data.path
            });
            cb(null, AWSS3.getPublicUrl(imageMediumName));
          });
        });
      }
    }, function(err, results) {
      //TODO - fix error
      cb(null, results);
    });
  }

  static queueUploadFile(options, cb) {
    Queue.create('UPLOAD_S3', {
      filePath: options.filePath,
      fileName: options.fileName,
      ACL: options.ACL || 'public-read',
      contentType: options.contentType || 'video/mp4'
    })
    .save(() => cb(null, AWSS3.getPublicUrl(fileName)));
  }


  static uploadVideo(file, id, module, destination, cb){
    console.log('id uploader--',id,file)

    if (!file) {
    console.log('id uploader--',file)

    return cb(null,null);
    }
    var date = new Date();
    var newFileName =
    StringHelper.randomString(7) +
    StringHelper.getExt(file.name || file.filename);

    var fileName =
    date.getFullYear().toString() +
    (date.getMonth() + 1).toString() +
    date.getDate().toString() +
    date.getHours().toString() +
    date.getMinutes().toString() +
    date.getSeconds().toString() +
    "_" +
    newFileName;
    var tempPath = file.path;
    var dir = path.join(config.videoTempFolder + "/" + module + "/" + id);
    

    console.log('dir--',dir)

    if (!fs.existsSync(dir)){
    UtilsHelper.mkdirpSync(dir,'0777'); // create directory if not present
    }

    var fileFullPath = dir + "/" + fileName;
    console.log('fileFullPath--',fileFullPath)

    async.auto({
    video: function(callback){
        file.mv(fileFullPath, function(err) {
        console.log('error--',err)
        if (err) {
            return cb(err);
        }
        console.log('fileFullPath--',fileFullPath)

        callback(null, destination + id + "/" + fileName);
        });
    },
    videoThumb:function(cb){
    
        let thumbName = '';
        new ffmpeg(fileFullPath)
        .on('filenames', function(filenames) {
        console.log("videoThumb filename=",filenames)
        thumbName = filenames[0];
        })
        .on('end', function() {
        console.log("videoThumb end")
        cb(null,  destination + id + "/" + thumbName);
        })
        .on('error', function(err){
        console.log("thumb video err=",err);
        })
        // take 2 screenshots at predefined timemarks and size
        .screenshot({
            folder: dir,
            filename: StringHelper.randomString(5) + '.png',
            size: '640x480',
            timemarks: [ '25%' ]
        },
        console.log("filename=..",fileName),
        );
    }
    
    
    }, function(err, result){
    console.log('result---',result)
    cb(err, result);
    });
}
}

module.exports = Uploader;
