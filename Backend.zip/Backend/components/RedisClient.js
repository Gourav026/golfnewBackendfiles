var config = require('../config/environment')

//var jsonify = require('redis-jsonify')

//redis with jsonify
//module.exports = jsonify(redis.createClient(config.redis));
module.exports = {} //redis.createClient(config.redis);
