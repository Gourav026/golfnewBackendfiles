//var nodemailer = require('nodemailer');
var pdf = require('html-pdf');

var options = { format: 'Letter' };
var mailComposer = require('mailcomposer')
var config = require('../config/environment/index')
const AWS = require("aws-sdk");
AWS.config.update({
    accessKeyId: config.AWS.accessKeyId,
    secretAccessKey: config.AWS.secretAccessKey,
    region: config.AWS.region
});

const ses = new AWS.SES({ apiVersion: "2010-12-01" });

//var adminLoginNotification = require('./userLoginHtml');

module.exports = function(mailType) {

    var from  = 'rajeevranjan.myself@gmail.com'//config.local.MAIL_USERNAME; // set default mail here

    // define mail types
    var mailDict = {
        "userMail" :{
            subject : "Welcome to Rx123",
            html    : require('./welcomeUser'),
        },
        "forgotPasswordMail" :{
            subject : "Forgot Password",
            html    : require('./forgotPasswordMail'),
        },
        "forgotPasswordResponse" :{
            subject : "Password Updation",
            html    : require('./forgotPasswordResponse'),
        },
        "emailVerificationMail" :{
            subject : "Email Verification",
            html    : require('./emailVerificationMail'),
        },
        "resetPasswordMail" :{
            subject : "Email For Reset Password",
            html    : require('./resetPasswordMail'),
        },
        "sendOTPdMail" :{
            subject : "OTP verification email",
            html    : require('./otpVerificationMail'),
        },
        "signupVerification" :{
            subject : "Sign up verification email",
            html    : require('./signupVerification'),
        },
        "petition" :{
            subject : "Sign Your Scorecard",
            html    : require('./petition'),
        },
        "sendFeedBack" :{
            subject : "Feedback",
            html    : require('./sendFeedBack'),
        },
        "feedback" :{
            subject : "Feedback",
            html    : require('./feedback'),
        },
        "adminToUserMail" :{
            subject : "Feedback From Calaf Admin",
            html    : require('./adminToUserMail'),
        }
    }

    // var transporter = nodemailer.createTransport(require('nodemailer-smtp-transport')({
    //     host    : "smtp.gmail.com",
    //     port    : 465,
    //     secure  : true,
    //     debug   : true,
    //     auth    : {
    //         user    : secretUser,
    //         pass    : secretPass 
    //         //new Buffer(secretPass,'base64').toString('ascii'),
    //         //xoauth2 : "U01UQ0tHczZuaVZGWUJnQ3BpbU5CQTVDWWwzYU1oNnJoNU9iMDFSVk5LMSszSURRY3pkTVVuOXo5WlJXMWpOc1o3YkhOc0kvMnBrPQ=="
    //     },    
    //     maxMessages : 100,
    //     requireTLS : true,
    // }));

    return function(to, data, sendPdf=false, pdfTemplate, pdfName) {  // pass mailbody only when sendPdf is true
        var self =  {
            send : function() {
                var mailOptions         = mailDict[mailType];
                mailOptions.Source      = config.AWS.SenderEmailId;
                mailOptions.Destination = {
                                             ToAddresses: [to] // Email address/addresses that you want to send your email
                                          }; 
                mailOptions.html = self.handleVars(mailOptions.html, data);
                mailOptions.Message = {
                                            Body: {
                                                Html: {
                                                // HTML Format of the email
                                                Data:
                                                        mailOptions.html
                                                }
                                                // Text: {
                                                // Data: "Thanks for reaching out"
                                                // }
                                            },
                                            Subject: {
                                                Data: mailOptions.subject
                                            }
                                        }
                //delete mailOptions.html;
                //delete mailOptions.subject;
                
                if(sendPdf) {
                    console.log('send pdf enter');
                    pdf.create(pdfTemplate, options).toFile(config.clientFolder+'/emailpdf/'+pdfName+'.pdf', function(err, res) {
                        if (err) return console.log(err);
                        console.log('res--->',res); // { filename: '/app/businesscard.pdf' }
                      
                        mailComposer({
                            from: config.AWS.SenderEmailId,
                            replyTo: to,
                            to: to,
                            subject: mailOptions.subject,
                            html: mailOptions.html,
                            attachments: [
                            {
                                path: res.filename
                            },
                            ],
                        }).build((err, message) => {

                            if (err) {
                            console.error(`Email encoding error: ${err}`);
                            }

                            let sendEmailReceiver =  ses.sendRawEmail({RawMessage: {Data: message}}).promise();
                            
                            sendEmailReceiver
                            .then(data => {
                                console.log("Message send successfully !", data);
                                
                            })
                            .catch(error => {
                                console.log(error);
                                return ;
                            });

                        })

                    });

                } else {
                    console.log('normal email enter');
                    let sendEmailReceiver = ses.sendEmail({
                        Source: config.AWS.SenderEmailId,
                        ReplyToAddresses: [to],
                        Destination: {
                          ToAddresses: [to],
                        },
                        Message: {
                          Subject: {
                            Data: mailOptions.subject,
                          },
                          Body: {
                            Html: {
                                // HTML Format of the email
                                Data: mailOptions.html
                            },
                          },
                        },
                      }).promise();
                    // send mail with defined transport object
                                    
                    sendEmailReceiver
                    .then(data => {
                        console.log("Message send successfully !", data);
                        
                    })
                    .catch(error => {
                        console.log(error);
                        return ;
                    });

                    // transporter.sendMail(mailOptions, function(error, info){
                    //     if(error){
                    //         console.log('Error sending mail');
                    //         console.log(error);
                    //         return ;
                    //     }
                    //     console.log('Message sent: ' + info.response);
                    // });
                }
            },
            //transporter : transporter,
            getMappedValue : function(s, o) { // cannot handle arrays
                var l = s.split(".");
                var r = o;
                if(l.length > 0) {
                    l.forEach(function(v, i) {
                        if(v && r[v] !== undefined) {
                            r = r[v];
                        }
                    })
                    return r;
                }
                return undefined;
            },
            handleVars : function(html, o) {
                (html.match(/\{\{\s+([^}]*)\s+\}\}/g) || []).forEach(function(w, i) {
                    var s = w.replace(/^\{\{\s+/, "").replace(/\s+\}\}$/, "");
                    var v = self.getMappedValue(s, o);

                    // handle special cases that need processing
                    // date
                    if(s === 'publishedDate' && v != undefined) {
                        // locale format date
                        v = new Date(v).toString();
                    }
                    if(s==='@validUpto' && v ===null){
                        v = 'NA';
                    }
                    if(s==='@userTotalSpace' && v===null){
                        v=0;
                    }
                    if(s==='@userFreeSpace' && v===null){
                        v=0;
                    }
                    if(s==='@currentPlan' && v===null){
                        v='Freedom';
                    }
                    if(s==='@userJunkSpace' && v===null){
                        v=0;
                    }
                    // replace
                    if(v !== undefined) {
                        html = html.replace(w, String(v));
                    }
                })
                return html;
            },
        };
        return self;
    }
}
// usage
// require("./modules/sendmail")('userSignupSuccess')("to@to.to", data).send();
