module.exports =
'<body style="background-color:rgb(235, 235, 235); margin: 25px;">\
<div style="background-color:white;width: 75%;margin: auto;padding: 10px;border-radius: 30px;box-shadow: 1px 1px 10px rgba(148,81,143,255)">\
<imgsrc="https://www.addydigital.com/wp-content/uploads/2020/12/Addy_Digital_Logo-e1607881293784.png"alt="My logo"style="display: block;margin-left: 5%;margin-right: 5%;margin-bottom: 25px;margin-top: 25px;width: 10%;loat: left;">\
<h1 style="margin-left: 5%;margin-right: 5%;text-align: left;font-size: 30px;">Reset Password?</h1>\
<br>\
<div style="margin: 5%">\
<p style="text-align: left;font-size: 20px;">Hello User,</p>\
<p style="text-align: left;font-size: 20px;">&emsp;&emsp;&emsp;&emsp;&ensp;Thankyou for contacting BackSpin.</p>\
<p style="text-align: left;font-size: 20px;">We have reveived a password change request for the account related tothis email id.if you wish to continue please click on the button below.</p>\
</div>\
<br>\
<button style="display: inline;background-color: #7b38d8;border-radius: 50px;border: 4px double #cccccc;color: #eeeeee;text-align: center;font-size: 20px;width: 80%;margin: 0% 0% 0% 10%;padding: 10px;-webkit-transition: all 0.5s;-moz-transition: all 0.5s;-o-transition: all 0.5s;transition: all 0.5s;cursor: pointer"> Reset Password </button>\
</div>\
</body>';
