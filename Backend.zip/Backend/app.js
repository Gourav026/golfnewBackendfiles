
const {app,server} = require('./index')

//-----------------------server start----------------------------------
server.listen(process.env.PORT || '5000', function (err) {
    if (err) {
        throw err;
    } else {
        console.log("Server is running at http://localhost:" + 5000);
    }
});
server.timeout = 5000000;