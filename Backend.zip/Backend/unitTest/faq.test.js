const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
const { app,server } = require('../index')
var before = require('mocha').before;



const { userOne,setupDatabase , faqOne,countryOne,stateOne} = require('./utils/user')


before(setupDatabase);


describe('POST /admin/v1/faq/add', function(){
    it('Should add a new faq record', function(done){
        data={
                description:"hii",
                title:"new title"
          }
         request(app)
          .post('/admin/v1/faq/add')
          .send(data)
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
              //console.log("res=====",res.body)
              expect(res.body.response).to.include(data);
              if (err) return done(err);
              return done();
      });
  }); 
});



describe('GET /api/v1/faq', function() {
    it('Should get all faq', function(done) {
      request(app)
        .get('/api/v1/faq')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



describe(`PUT /admin/v1/faq/${faqOne._id}`, function() {
it('Should update faq', function(done) {
    console.log("faqid_______________________>",faqOne._id);
    request(app)
    .put(`/admin/v1/faq/${faqOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)
    .send({
            description:'test faqy',
        })        
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  

describe(`DELETE /admin/v1/faq/${faqOne._id}`, function() {
it('Should delete faq', function(done) {
    request(app)
    .delete(`/admin/v1/faq/${faqOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)       
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  

