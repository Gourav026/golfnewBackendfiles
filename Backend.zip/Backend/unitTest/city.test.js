const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { CitySchema } = require('../schema/api')
var before = require('mocha').before;
// const {stateOne} = require('./utils/state')
const { userOne,setupDatabase , cityOne,countryOne,stateOne} = require('./utils/user')
// const {countryOne} = require('./utils/country')
const stateId = new mongoose.Types.ObjectId()



before(setupDatabase);

        describe('POST /api/v1/city/add', function(){
            it('Should register a new City record', function(done){
                 request(app)
                  .post('/api/v1/city/add')
                  .send({
                      "name":"Mumbai",
                      "countryId":`${countryOne._id}`,
                      "stateId":`${stateOne._id}`

                  })
                  .expect('Content-Type', /json/)
                  .expect(200)
                  .end(function(err, res) {
                      if (err) return done(err);
                      return done();
              });
          }); 
          });
 
  describe('GET /api/v1/city', function() {
      it('Should get all city', function(done) {
        request(app)
          .get('/api/v1/city')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  


    describe(`PUT /api/v1/city/${cityOne._id}`, function() {
        it('Should update city', function(done) {
          console.log("Cityid_______________________>",cityOne._id);
          request(app)
            .put(`/api/v1/city/${cityOne._id}`)
            .set('authorization',`Bearer ${userOne.authToken}`)
            .send({"name":'Bangalore'})        
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  
      
      describe(`DELETE /api/v1/city/${cityOne._id}`, function() {
        it('Should delete city', function(done) {
          request(app)
            .delete(`/api/v1/city/${cityOne._id}`)
            .set('authorization',`Bearer ${userOne.authToken}`)       
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  