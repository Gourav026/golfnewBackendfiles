const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { CountrySchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,setupDatabase ,countryOne} = require('./utils/user')
const countryId = new mongoose.Types.ObjectId()


before(setupDatabase);

describe('POST /api/v1/country/add', function(){
   it('Should register a new country record', function(done){
        request(app)
         .post('/api/v1/country/add')
         .send({
             "name":"Srilanka",
         })
         .expect('Content-Type', /json/)
         .expect(200)
         .end(function(err, res) {
             if (err) return done(err);
             return done();
     });
 }); 
 });

 describe('GET /api/v1/country', function() {
     it('Should get all country', function(done) {
       request(app)
         .get('/api/v1/country')
         .expect('Content-Type', /json/)
         .expect(200)
         .end(function(err, res) {
           if (err) return done(err);
          return done();
         });
     });
   });  
  

//   describe(`PUT /api/v1/country/${countryOneId}`, function(){
//      it('Should update a new country record', function(done){
//         console.log('signUserToken------------>',signUserToken);
//         request(app)
//         .put(`/api/v1/country/${countryOneId}`)
//         .set({'Accept': 'application/json', 'authorization': `Bearer ${signUserToken}`})
//         // .set('authorization', `Bearer ${signUserToken}`)
//         .send({
//             "name":"Singapore",
//         })
//         .expect('Content-Type', /json/)
//         .expect(200)
//         .end(function(err, res) {
//             if (err) return done(err);
//             return done();
//     });
// }); 
// });


describe(`PUT /api/v1/country/${countryOne._id}`, function() {
    it('Should update country', function(done) {
      request(app)
        .put(`/api/v1/country/${countryOne._id}`)
        .set('authorization',`Bearer ${userOne.authToken}`)
        .send({name:'Japan'})        
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
          return done();
        });
    });
  });  
  
  describe(`DELETE /api/v1/country/${countryOne._id}`, function() {
    it('Should delete country', function(done) {
      request(app)
        .delete(`/api/v1/country/${countryOne._id}`)
        .set('authorization',`Bearer ${userOne.authToken}`)       
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
          return done();
        });
    });
  });  
  


