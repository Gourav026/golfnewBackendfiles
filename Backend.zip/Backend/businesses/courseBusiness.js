var { CourseSchema } =require('../schema/api')
var fs = require('fs')

class CourseBusiness {
  /** 
   * create a new course
   * @param  {Object} data course data
   * @return {Promise}
   */
  static create(data) {
    var newCourse = new CourseSchema(data);
    return newCourse.save().then((course) => {
      //fire event to another sides
    console.log('course--->',course)
    return course
    });
  }

  /**
   * update course
   * @param  {Object} Mongoose course object
   * @return {Promise}
   */
  static update(course) {
    return course.save().then((updated) => {
     return updated
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data course data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }
/**
   * Unlink all data by query
   * @param  {Object} data user data
   * @return {Promise}
   */
 static unlinkFile(params) {
  //TODO - code me
  let promise = new Promise((resolve, reject) => {

    let filePath = `./public/${params}`;
    fs.unlink(filePath, (err) => {
        if (err) {
            console.log('err', err);
            reject(err)
        } else {
            console.log(params + ' was deleted');
            resolve(params + ' was deleted');

        }
    });
  });

  return promise;
}
  /**
   * find list of courses
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  // static find(params) {
  //   console.log('find hitted');
    
  //   var ObjectId = require('mongoose').Types.ObjectId;
  //   var condition = {};
  //   var limit = 0;
  //   var sort = 'createdAt';
  //   var order = -1;
  //   if(params._id !== undefined){
  //     console.log('params._id hitted',params._id);

  //     condition = {
  //     _id: {$eq: new ObjectId(params._id)}
  //     }
  //   }

  //   if(typeof params.sort != 'undefined'){
  //       sort = params.sort;
  //   }
  //   if(typeof params.order != 'undefined'){
  //     order = params.order;
  //   }
  //   if(params.status=='active'){
  //       condition.status = params.status;
  //   }
  //   if(typeof params.keyword != 'undefined' && params.sort != null){
  //     var regex = new RegExp(params.keyword, "i")
  //     condition = {'$or':[{name : regex},{email : regex}]};
  //   }
  //   if(params.limit !== 'undefined'){
  //     var filter = { sortCheck : order};
  //     filter[sort] = filter.sortCheck;
  //     delete filter.sortCheck;
  //     limit =   params.limit;
  //   }
     

  // }
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }


      if(params.page){
        page =   params.page -1;
        skip =   page*limit;
      }
       console.log('limit',limit)
       var aggregate = CourseSchema.aggregate([
        {
            $match: condition
        },
        
        { 
            $lookup : {
                from : 'countries',
                localField : 'countryId',
                foreignField : '_id',
                as : 'countryId'
            }
        },
        {
            $unwind : { path : '$countryId', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'states',
                localField : 'stateId',
                foreignField : '_id',
                as : 'stateId'
            }
        },
        {
            $unwind : { path : '$stateId', preserveNullAndEmptyArrays : true } 
        },
        {
          $lookup : {
              from : 'cities',
              localField : 'cityId',
              foreignField : '_id',
              as : 'cityId'
          }
        },
        {
            $unwind : { path : '$cityId', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'coursedetails',
                localField : '_id',
                foreignField : 'courseId',
                as : 'coursedetails'
            }
        },
        {
            $unwind : { path : '$coursedetails', preserveNullAndEmptyArrays : true } 
        },
        
        {
            $project : {
                _id : 1,
                name : 1,
                description : 1,
                photo: 1,
                imageMediumPath: 1,
                imageThumbPath : 1,
                countryId: {
                    _id:"$countryId._id",
                    name:"$countryId.name",
                    status:"$countryId.status"
                },
                stateId: {
                    _id:"$stateId._id",
                    name:"$stateId.name",
                    status:"$stateId.status"
                },
                cityId: {
                  _id:"$cityId._id",
                  name:"$cityId.name",
                  status:"$cityId.status"
                },
                geoLocation:1,
                rating : 1,
                totalTimesPlayed:1,
                redYard:1,
                blueYard:1,
                yellowYard:1,
                whiteYard:1,
                lastRecord: 1,
                status   :  1,
                coursedetails:1,
                updatedAt:1
            }
        }, 
        {
            $group : {
                _id :"$_id",
                name : {
                    "$first": "$name"
                },
                description : {
                  "$first": "$description"
                },
                redYard : {
                  "$first": "$redYard"
                },
                blueYard : {
                  "$first": "$blueYard"
                },
                whiteYard : {
                  "$first": "$whiteYard"
                },
                yellowYard : {
                  "$first": "$yellowYard"
                },
                photo : {
                "$first": "$photo"
                },
                imageMediumPath : {
                "$first": "$imageMediumPath"
                },
                imageThumbPath: {
                    "$first": "$imageThumbPath"
                },
                countryId : {
                    "$first": "$countryId"
                },
                stateId : {
                    "$first": "$stateId"
                },
                cityId : {
                  "$first": "$cityId"
                }, 
                rating : {
                  "$first": "$rating"
                },
                lastRecord : {
                  "$first": "$lastRecord"
                },
                status : {
                  "$first": "$status"
                },
                geoLocation:{
                  "$first":"$geoLocation"
                },
                totalTimesPlayed:{
                  "$first":"$totalTimesPlayed"
                },
                coursedetails:{
                  "$addToSet":"$coursedetails"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                name:1,
                description:1,
                photo:1,
                imageMediumPath:1,
                imageThumbPath:1,
                countryId : 1,
                stateId: 1,
                cityId:1,
                rating: 1,
                redYard:1,
                blueYard:1,
                yellowYard:1,
                whiteYard:1,
                geoLocation:1,
                lastRecord:1,
                status: 1,
                coursedetails:1,
                totalTimesPlayed:1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : {
            metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }
  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return CourseSchema.findOne(params).exec();
  }


  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return CourseSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }

  static courseList(params){

    console.log('courseList hitted');
   
    
    let ObjectId = require('mongoose').Types.ObjectId;
    let condition = {};
    let limit = 10;
    let sort = 'createdAt';
    let order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)},
      role:'course'
      }
    }
    //console.log("hiiiii-..")
    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }

   return CourseSchema.find(condition).sort({name:1}).exec();


   }

}

module.exports = CourseBusiness;
