var { RoundSchema } =require('../schema/api')
var fs = require('fs')
var fcmNotification = require('../modules/fcmNotification');

class RoundBusiness {
  /**
   * create a new round
   * @param  {Object} data round data
   * @return {Promise}
   */
  static start(data) {
    var newRound = new RoundSchema(data);
    return newRound.save().then((round) => {
      //fire event to another sides
    console.log('round--->',round)
    return round
    });
  }

  /**
   * update round
   * @param  {Object} Mongoose round object
   * @return {Promise}
   */
  static update(round) {
    return round.save().then((updated) => {
     return updated
    });
  }

  /**
   * find list of rounds
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    

    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       console.log('limit',limit)
       var aggregate = RoundSchema.aggregate([
        {
            $match: condition
        },
        
        { 
            $lookup : {
                from : 'users',
                localField : 'player1',
                foreignField : '_id',
                as : 'player1'
            }
        },
        {
            $unwind : { path : '$player1', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player2',
                foreignField : '_id',
                as : 'player2'
            }
        },
        {
            $unwind : { path : '$player2', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player3',
                foreignField : '_id',
                as : 'player3'
            }
        },
        {
            $unwind : { path : '$player3', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player4',
                foreignField : '_id',
                as : 'player4'
            }
        },
        {
            $unwind : { path : '$player4', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'courses',
                localField : 'courseId',
                foreignField : '_id',
                as : 'courseId'
            }
        },
        {
            $unwind : { path : '$courseId', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'rounddetails',
                localField : '_id',
                foreignField : 'roundId',
                as : 'roundDetails'
            }
        },
        {
            $unwind : { path : '$roundDetails', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'roundDetails.playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
    
        {
            $project : {
                _id : 1,
                name : 1,
                startingHole : 1,
                lastUpdatedHole:1,
                roundDetails:
                            {
                                _id:"$roundDetails._id",
                                holeNumber:"$roundDetails.holeNumber",
                                updatedAt:"$roundDetails.updatedAt"
                            },
                modeSelection:1,
                player:[ 
                    {
                        _id:"$player1._id",
                        firstName:"$player1.firstName",
                        lastName:"$player1.lastName",
                        photo:"$player1.photo",
                        imageThumbPath:"$player1.imageThumbPath",
                        imageMediumPath:"$player1.imageMediumPath",
                    },
                    {
                        _id:"$player2._id",
                        firstName:"$player2.firstName",
                        lastName:"$player2.lastName",
                        photo:"$player2.photo",
                        imageThumbPath:"$player2.imageThumbPath",
                        imageMediumPath:"$player2.imageMediumPath",
                    },
                    {
                        _id:"$player3._id",
                        firstName:"$player3.firstName",
                        lastName:"$player3.lastName",
                        photo:"$player3.photo",
                        imageThumbPath:"$player3.imageThumbPath",
                        imageMediumPath:"$player3.imageMediumPath",
                    },
                    {
                        _id:"$player4._id",
                        firstName:"$player4.firstName",
                        lastName:"$player4.lastName",
                        photo:"$player4.photo",
                        imageThumbPath:"$player4.imageThumbPath",
                        imageMediumPath:"$player4.imageMediumPath",
                    }
                ],
                courseId: {
                    _id:"$courseId._id",
                    name:"$courseId.name",
                    description:"$courseId.description"
    
                },
                lastRecord   :  1,
                lastRecordBy: {
                    _id:"$lastRecordBy._id",
                    name:"$lastRecordBy.name",
                    description:"$lastRecordBy.description",
                    photo:"$lastRecordBy.photo",
                    imageThumbPath:"$lastRecordBy.imageThumbPath",
                    imageMediumPath:"$lastRecordBy.imageMediumPath",
                },

                updatedAt:1
            }
        }, 
        {
            $group : {
                _id :"$_id",
                name : {
                    "$first": "$name"
                },
                startingHole : {
                    "$first": "$startingHole"
                },
                lastUpdatedHole:{
                    "$first": "$lastUpdatedHole"
                },
                player : {
                    "$first": "$player"
                },
                roundDetails:{
                    "$addToSet":"$roundDetails"
                },
                modeSelection : {
                    "$first": "$modeSelection"
                },
                courseId : {
                    "$first": "$courseId"
                },
                lastRecord   :  {
                    "$first": "$lastRecord"
                },
                lastRecordBy: {
                    "$first": "$lastRecordBy"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                name : 1,
                startingHole : 1,
                lastUpdatedHole : 1,
                player:{
                    "$cond": [
                        { "$eq": [ "$player", [{}] ] },
                        { "$const": null },
                        "$player"
                    ]
                },
                courseId: 1,
                roundDetails:1,
                lastRecord   :  1,
                modeSelection:1,
                lastRecordBy: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : {
            metadata: [ { $count: "total" }, { $addFields: { page: page } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ], // add projection here wish you re-shape the docs
            resource : [
                {
                    $project:{
                        latestHoleNumber: { $add: [ { $size: "$roundDetails"}, 1 ] },
                    }
                }
              ]
        } 
        }
    ]

    ).exec()

    return aggregate
  }


  /**
   * find list of rounds
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findByAdmin(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       console.log('limit',limit)
       var aggregate = RoundSchema.aggregate([
        {
            $match: condition
        },
        
        { 
            $lookup : {
                from : 'users',
                localField : 'player1',
                foreignField : '_id',
                as : 'player1'
            }
        },
        {
            $unwind : { path : '$player1', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player2',
                foreignField : '_id',
                as : 'player2'
            }
        },
        {
            $unwind : { path : '$player2', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player3',
                foreignField : '_id',
                as : 'player3'
            }
        },
        {
            $unwind : { path : '$player3', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'player4',
                foreignField : '_id',
                as : 'player4'
            }
        },
        {
            $unwind : { path : '$player4', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'courses',
                localField : 'courseId',
                foreignField : '_id',
                as : 'courseId'
            }
        },
        {
            $unwind : { path : '$courseId', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'rounddetails',
                localField : '_id',
                foreignField : 'roundId',
                as : 'roundDetails'
            }
        },
        {
            $unwind : { path : '$roundDetails', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup : {
                from : 'users',
                localField : 'roundDetails.playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
    
        {
            $project : {
                _id : 1,
                name : 1,
                startingHole : 1,
                modeSelection:1,
                player1: {
                    _id:"$player1._id",
                    firstName:"$player1.firstName",
                    lastName:"$player1.lastName",
                    photo:"$player1.photo",
                    imageThumbPath:"$player1.imageThumbPath",
                    imageMediumPath:"$player1.imageMediumPath",
                },
                player2: {
                    _id:"$player2._id",
                    firstName:"$player2.firstName",
                    lastName:"$player2.lastName",
                    photo:"$player2.photo",
                    imageThumbPath:"$player2.imageThumbPath",
                    imageMediumPath:"$player2.imageMediumPath",
                },
                player3: {
                    _id:"$player3._id",
                    firstName:"$player3.firstName",
                    lastName:"$player3.lastName",
                    photo:"$player3.photo",
                    imageThumbPath:"$player3.imageThumbPath",
                    imageMediumPath:"$player3.imageMediumPath",
                },
                player4: {
                    _id:"$player4._id",
                    firstName:"$player4.firstName",
                    lastName:"$player4.lastName",
                    photo:"$player4.photo",
                    imageThumbPath:"$player4.imageThumbPath",
                    imageMediumPath:"$player4.imageMediumPath",
                },
                courseId: {
                    _id:"$courseId._id",
                    name:"$courseId.name",
                    description:"$courseId.description"
    
                },
                lastRecord   :  1,
                lastRecordBy: {
                    _id:"$lastRecordBy._id",
                    name:"$lastRecordBy.name",
                    description:"$lastRecordBy.description",
                    photo:"$lastRecordBy.photo",
                    imageThumbPath:"$lastRecordBy.imageThumbPath",
                    imageMediumPath:"$lastRecordBy.imageMediumPath",
                },

                updatedAt:1
            }
        }, 
        {
            $group : {
                _id :"$_id",
                name : {
                    "$first": "$name"
                },
                startingHole : {
                    "$first": "$startingHole"
                },
                player1 : {
                    "$first": "$player1"
                },
                player2 : {
                    "$first": "$player2"
                },
                player3 : {
                    "$first": "$player3"
                },
                player4 : {
                    "$first": "$player4"
                },
                modeSelection : {
                    "$first": "$modeSelection"
                },
                courseId : {
                    "$first": "$courseId"
                },
                lastRecord   :  {
                    "$first": "$lastRecord"
                },
                lastRecordBy: {
                    "$first": "$lastRecordBy"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                name : 1,
                startingHole : 1,
                player1: 1,
                player2: 1,
                player3: 1,
                player4: 1,
                courseId: 1,
                lastRecord   :  1,
                modeSelection:1,
                lastRecordBy: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : {
            metadata: [ { $count: "total" }, { $addFields: { page: page } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }

    /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return RoundSchema.findOne(params).exec();
  }


  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return RoundSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }
  
  /**
   * notification
   */
  static async sendNotification(friendRequestNotified, toUser, notification) {
    //console.log('enter notification', friendRequestNotified, toUser, notification);
    if(!friendRequestNotified){
                  
      let notificationData = {
          title:'Friend Request',
          excludeUserId : notification.fromUser,
          toUser   : notification.toUser,
      }
      await fcmNotification.fcmSentPush(
        notificationData, 
        toUser.deviceId, 
        `Hello ${toUser.firstName} ${toUser.lastName},
        ${notification.message}`
        )
      }
    
      let notificationData = {
        title:'Notification for Game Started',
        excludeUserId : notification.fromUser,
        toUser   : notification.toUser,
      }
      await fcmNotification.fcmSentPush(
        notificationData, 
        toUser.deviceId, 
        `Hello ${toUser.firstName} ${toUser.lastName},
        Welcome Round has started. 
        Best of luck`
        )  
    }

}

module.exports = RoundBusiness;
