var { CitySchema } =require('../schema/api')
var fs = require('fs')

class CityBusiness {
  /**
   * create a new city
   * @param  {Object} data city data
   * @return {Promise}
   */
  static create(data) {
    var newCity = new CitySchema(data);
    return newCity.save().then((city) => {
      //fire event to another sides
    console.log('city--->',city)
    return city
    });
  }

  /**
   * update city
   * @param  {Object} Mongoose city object
   * @return {Promise}
   */
  static update(city) {
    return city.save().then((updated) => {
     return updated
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data city data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of citys
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page -1;
        skip =   page*limit;
      }

       console.log('limit',limit)
       let aggregate=CitySchema.aggregate([
        {
          $match:condition
        },
        {
          $lookup:{
            from:'states',
            localField:'stateId',
            foreignField:'_id',
            as:'stateId'
          }
        },
        {
          $unwind:{
            path:'$stateId', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $lookup:{
            from:'countries',
            localField:'countryId',
            foreignField:'_id',
            as:'countryId'
          }
        },
        {
          $unwind:{
            path:'$countryId', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $project:{
            _id:1,
            name:1,
            status:1,
            latitude:1,
            longitude:1,
            countryId:{
              _id:"$countryId._id",
              name:"$countryId.name",
              status:"$countryId.status"
            },
            stateId:{
              _id:"$stateId._id",
              name:"$stateId.name",
              status:"$stateId.status"
            },
            updatedAt:1
          }
        },
        {
          $group:{
            _id:"$_id",
            name:{
              "$first":"$name"
            },
            latitude:{
              "$first":"$latitude"
            },
            longitude:{
              "$first":"$longitude"
            },
            status:{
              "$first":"$status"
            },

            countryId:{
              "$first":"$countryId"
            },
            stateId:{
              "$first":"$stateId"
            },
            updatedAt:{
              "$first":"$updatedAt"
            },
  
          }
        },
        {
          $project:{
            _id:1,
            name:1,
            status:1,
            latitude:1,
            longitude:1,
            countryId:1,
            stateId:1,
            updatedAt:1
          }
        },
        {
          $sort:{updatedAt:-1}
        },
        { 
          '$facet'    : {
          metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit} } ],
          data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
           } 
      }
      ]).exec();
  
      return aggregate;
    }


  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return CitySchema.findOne(params).exec();
  }

   /**
   * find list of city
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findByAdmin(params) {
    console.log('find hitted');
   
    
    let ObjectId = require('mongoose').Types.ObjectId;
    let condition = {};
    let limit = 10;
    let sort = 'createdAt';
    let order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }
    //console.log("hiiiii-..")
    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }

   return CitySchema.find(condition).sort({name:1}).exec();

   
  }
  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return CitySchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }

}

module.exports = CityBusiness;
