const { resolve } = require('bluebird');
let {NotificationSchema}= require('../schema/api')

class NotificationBusiness{

  /**
   * create a new newsFeedDetail
   * @param  {Object} data newsfeed data
   * @return {Promise}
   */
  static create(data) {
    var newNotification = new NotificationSchema(data);
    return newNotification.save().then((notification) => {
    return notification
    })
    .catch(err=>{
      return err;
    })
  }

  /**
   * update notification
   * @param  {Object} Mongoose notification object
   * @return {Promise}
   */
  static update(notification) {
    return notification.save().then((updated) => {
     return updated
    });
  }

  /**
   * find list of courses
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }

    if(params.fromUser){
        condition.fromUser = new ObjectId(params.fromUser);
    }

    if(params.toUser){
        condition.toUser = new ObjectId(params.toUser);
    }

    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }

    if(params.limit){
        var filter = { sortCheck : order};
        filter[sort] = filter.sortCheck;
        delete filter.sortCheck;
        limit =   params.limit;
    }

    if(params.page){
        page =   params.page -1;
        skip =   page*limit;
    }

    console.log('limit',limit)
    var aggregate = NotificationSchema.aggregate([
        {
            $match: condition
        },
        {
            $lookup:{
              from:"users",
              localField:"fromUser",
              foreignField:"_id",
              as:"fromUser"
            }
        },
        {
          $unwind : { path : '$fromUser', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup:{
              from:"users",
              localField:"toUser",
              foreignField:"_id",
              as:"toUser"
            }
        },
        {
          $unwind : { path : '$toUser', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                _id : 1,
                fromUser:{
                  _id:"$fromUser._id",
                  firstName:"$fromUser.firstName",
                  lastName:"$fromUser.lastName",
                  photo:"$fromUser.photo"
                },
                toUser:{
                  _id:"$toUser._id",
                  firstName:"$toUser.firstName",
                  lastName:"$toUser.lastName",
                  photo:"$toUser.photo"
                },
                message:1,
                type:1
            }
        }, 
        {
            $group : {
                _id :"$_id",
                fromUser : {
                  "$first": "$fromUser"
                },
                toUser : {
                  "$first": "$toUser"
                },
                message : {
                  "$first": "$message"
                },
                type : {
                  "$first": "$type"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : { 
            metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }


    /**
     * find single record by params
     * @param  {Object} params Mongo query
     * @return {Promise}
     */
    static findOne(params) {    
        return NotificationSchema.findOne(params).exec();
    }

    /**
     * delete account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
    static delete(id) {
      return NotificationSchema.findByIdAndRemove(id).exec()
      .then((data) => {

        return data;
      });
    }

     
}

module.exports = NotificationBusiness;