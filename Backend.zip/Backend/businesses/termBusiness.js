var { TermSchema } =require('../schema/api')
var fs = require('fs')

class TermBusiness {
  /**
   * create a new term
   * @param  {Object} data term data
   * @return {Promise}
   */
  static create(data) {
    var newTerm = new TermSchema(data);
    return newTerm.save().then((term) => {
      //fire event to another sides
    console.log('term--->',term)
    return term
    });
  }

  /**
   * update term
   * @param  {Object} Mongoose term object
   * @return {Promise}
   */
  static update(term) {
    return term.save().then((updated) => {
    return updated
     
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data term data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of terms
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted')
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='true' || params.status=='false'){
        condition.status = params.status;
    }

		if(params.description != 'undefined'){

      condition.description = new RegExp(params.description, 'i')

    }

     if(params.limit){
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

      if(params.skip){
        skip =   params.skip;
      }

       var aggregate = TermSchema.aggregate([
        {
            $match: condition
        },
        {
            $group : {
                _id :"$_id",
                description : {
                    "$first": "$description"
                },
                status : {
                    "$first": "$status"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                description : 1,
                status: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : {
            metadata: [ { $count: "total" }, { $addFields: { page: page, limit: limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }

  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return TermSchema.findOne(params).exec();
  }

  static findOneByAdmin(params) {
    return TermSchema.findOne(params).exec();
  }

  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return TermSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }
}

module.exports = TermBusiness;
