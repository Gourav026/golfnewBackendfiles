let {HelpSchema}= require("../schema/api");

class HelpBusiness{

    //==================== Creata a HELP ==================
    static create(data)
    {
        let Helpdata=new HelpSchema(data);
        return Helpdata.save().then((help)=>{
            console.log("help--->",help);
            return help;
        })
    }

      /**
   * find list of help
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
        var filter = { sortCheck : order};
        filter[sort] = filter.sortCheck;
        delete filter.sortCheck;
        limit =   params.limit;
    }


    if(params.page){
        page =   params.page -1;
        skip =   page*limit;
    }
    console.log('limit',limit)
    var aggregate = HelpSchema.aggregate([
        {
            $match: condition
        },
        
        
        {
            $project : {
                _id : 1,
                description : 1,
                title:1,
                status   :  1,
                updatedAt:1,
            }
        }, 
        {
            $group : {
                _id :"$_id",
                description : {
                  "$first": "$description"
                },
                title : {
                    "$first": "$title"
                  },
                status : {
                  "$first": "$status"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }

            }
        },
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : { 
            metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }


    /**
     * update help
     * @param  {Object} Mongoose help object
     * @return {Promise}
     */
    static update(help) {
        return help.save().then((updated) => {
        return updated
        });
    }


  /**
     * find single record by params
     * @param  {Object} params Mongo query
     * @return {Promise}
     */
    static findOne(params) {     
        return HelpSchema.findOne(params).exec();
    }

    /**
     * delete account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
    static delete(id) {
      return HelpSchema.findByIdAndRemove(id).exec()
      .then((data) => {

        return data;
      });
    }


}

module.exports= HelpBusiness