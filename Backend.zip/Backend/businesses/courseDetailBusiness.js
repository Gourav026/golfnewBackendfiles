var { CourseDetailSchema,CourseSchema } =require('../schema/api')
var { Uploader } = require('../components')
var config = require('../config/environment')

var fs = require('fs')

class CourseDetailBusiness {
  /**
   * create a new courseDetail
   * @param  {Object} data courseDetail data
   * @return {Promise}
   */
  static create(data) {
    var newCourseDetail = new CourseDetailSchema(data);
    return newCourseDetail.save().then((courseDetail) => {
      //fire event to another sides
    console.log('courseDetail--->',courseDetail)
    return courseDetail
    });
  }

  /**
   * update courseDetail
   * @param  {Object} Mongoose courseDetail object
   * @return {Promise}
   */
  static update(courseDetail) {
    return courseDetail.save().then((updated) => {
     return updated
    });
  }

    /**
   * update bulk courseDetail
   * @param  {Object} Mongoose bulk courseDetail object
   * @return {Promise}
   */
  static bulkUpdate(courseDetailArray) {
    let updatedCourseDetail = []
    let promise = new Promise((resolve, reject) => {

        courseDetailArray.map( (courseDetail) => {
          console.log('courseDetail.photo------>', courseDetail.imagePreviewUrl)

          if(courseDetail._id)
          {
            if(courseDetail.imagePreviewUrl)
            {
              var convetedreplacestring = courseDetail.imagePreviewUrl.split("base64,")[1];
              console.log('convetedreplacestring------>',convetedreplacestring)
          
              courseDetail.imageType = config.imageType;
            let Func = Uploader.uploadImageWithBase64;
            Func(convetedreplacestring, courseDetail._id, 'courseDetails', '/uploads/images/courseDetails/', function(err, result) {
              
              if(result)
              {
              courseDetail.photo            = result.imageFullPath;
              courseDetail.imageMediumPath  = result.imageMediumPath;
              courseDetail.imageThumbPath   = result.imageThumbPath;

              CourseDetailSchema.update(
                {_id:courseDetail._id},
                {
                  $set:{
                    ...(( courseDetail.photo)           ? { photo : courseDetail.photo }                      : {}),
                    ...(( courseDetail.imageMediumPath) ? { imageMediumPath : courseDetail.imageMediumPath }  : {}),
                    ...(( courseDetail.imageThumbPath)  ? { imageThumbPath : courseDetail.imageThumbPath }    : {}),
                    
                  }
                }
              )
              .then((updated) => {
                console.log('updated info ---',updated);
              });
              }
              
            });
           }

          CourseDetailSchema.update(
            {_id:courseDetail._id},
            {
              $set:{
                ...(( courseDetail.par)             ? { par : courseDetail.par }                        : {}),
                ...(( courseDetail.blueYard)        ? { blueYard : courseDetail.blueYard }              : {}),
                ...(( courseDetail.whiteYard)       ? { whiteYard : courseDetail.whiteYard }            : {}),
                ...(( courseDetail.yellowYard)      ? { yellowYard : courseDetail.yellowYard }          : {}),
                ...(( courseDetail.redYard)         ? { redYard : courseDetail.redYard }                : {}),
                ...(( courseDetail.strokeIndex)     ? { strokeIndex : courseDetail.strokeIndex }        : {}),
                ...(( courseDetail.firstLatitude)   ? { firstLatitude : courseDetail.firstLatitude }    : {}),
                ...(( courseDetail.firstLongitude)  ? { firstLongitude : courseDetail.firstLongitude }  : {}),
                ...(( courseDetail.secondLatitude)  ? { secondLatitude : courseDetail.secondLatitude }  : {}),
                ...(( courseDetail.secondLongitude) ? { secondLongitude : courseDetail.secondLongitude} : {}),
                ...(( courseDetail.rotateDegree)    ? { rotateDegree : courseDetail.rotateDegree}       : {}),
                ...(( courseDetail.CenterLatLong.latitude)    ? { latitude : courseDetail.CenterLatLong.rotateDegree}       : {}),
                ...(( courseDetail.CenterLatLong.longitude)    ? { longitude : courseDetail.CenterLatLong.longitude}       : {}),
                ...(( courseDetail.CenterLatLong.latitudeDelta)    ? { latitudeDelta : courseDetail.CenterLatLong.latitudeDelta}       : {}),
                ...(( courseDetail.CenterLatLong.longitudeDelta)    ? { longitudeDelta : courseDetail.CenterLatLong.longitudeDelta}       : {}),
                
                
              }
            }
          )
          .then((updated) => {
            console.log('updated info ---',updated);
            updatedCourseDetail.push(updated)
          });
          }else{
            
          CourseDetailSchema.create(courseDetail)
          .then((updated) => {
            console.log('updated info ---',updated);
            if(courseDetail.imagePreviewUrl)
            {
              var convetedreplacestring = courseDetail.imagePreviewUrl.split("base64,")[1];
              console.log('convetedreplacestring------>',convetedreplacestring)
          
              courseDetail.imageType = config.imageType;
            let Func = Uploader.uploadImageWithBase64;
            Func(convetedreplacestring, updated._id, 'courseDetails', '/uploads/images/courseDetails/', function(err, result) {
              
              if(result)
              {
              courseDetail.photo            = result.imageFullPath;
              courseDetail.imageMediumPath  = result.imageMediumPath;
              courseDetail.imageThumbPath   = result.imageThumbPath;

              CourseDetailSchema.update(
                {_id:updated._id},
                {
                  $set:{
                    ...(( courseDetail.photo)           ? { photo : courseDetail.photo }                      : {}),
                    ...(( courseDetail.imageMediumPath) ? { imageMediumPath : courseDetail.imageMediumPath }  : {}),
                    ...(( courseDetail.imageThumbPath)  ? { imageThumbPath : courseDetail.imageThumbPath }    : {}),
                    
                  }
                }
              )
              .then((updated) => {
                console.log('updated info ---',updated);
              });
              }
              
            });
           }
          });
          }
          resolve(true);

          })
    }); 
    return promise
  }
  /**
   * Update all data by query
   * @param  {Object} data courseDetail data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of courseDetails
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
   
    
    let ObjectId = require('mongoose').Types.ObjectId;
    let condition = {};
    let limit = 10;
    let page=0;
    let skip=0;
    let sort = 'createdAt';
    let order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }
    console.log("hiiiii-..")
    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }

    if(params.courseId){
        condition.courseId = new ObjectId(params.courseId);
    }

    if(params.holeNumber){
      condition.holeNumber = parseInt(params.holeNumber);
    }

    if(params.page){
      page =   params.page -1;
      skip =   page*limit;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
    }
    console.log("params.limit=",params.limit)
    let aggregate=CourseDetailSchema.aggregate([
      {
        $match:condition
      },
      {
        $lookup:{
          from:'courses',
          localField:'courseId',
          foreignField:'_id',
          as:'courseId'
        }
      },
      {
        $unwind:{
          path:'$courseId', 
          preserveNullAndEmptyArrays : true
        }
      },
      {
        $lookup:{
          from:'states',
          localField:'courseId.stateId',
          foreignField:'_id',
          as:'stateId'
        }
      },
      {
        $unwind:{
          path:'$stateId', 
          preserveNullAndEmptyArrays : true
        }
      },
      
      {
        $project:{
         
          courseId:{
            _id:"$courseId._id",
            stateId:{
              _id:"$stateId._id",
              name:"$stateId.name"
            },
            name:"$courseId.name",
            photo:"$courseId.photo",
            geoLocation:"$courseId.geoLocation",
            updatedAt:"$courseId.updatedAt"
          },
         
          _id:1,
          holeNumber:1,
          par:1,
          blueYard:1,
          firstLatitude:1,
          firstLongitude :1,
          secondLatitude:1,
          secondLongitude:1,
          whiteYard:1,
          yellowYard:1,
          redYard:1,
          geoLocation:1,
          strokeIndex:1,
          scoringAverage:1,
          CenterLatLong:1,
          rotateDegree:1
          
        }
      },

      {
        $group:{
          
          
            _id:"$_id",
            courseId:{
              "$first":"$courseId",
            },
            holeNumber:{
              "$first":"$holeNumber"
            },
            par:{
              "$first":"$par"
            },
            blueYard:{
              "$first":"$blueYard"
            },
            whiteYard:{
              "$first":"$whiteYard"
            },
            yellowYard:{
              "$first":"$yellowYard"
            },
            redYard:{
              "$first":"$redYard"
            },
            strokeIndex:{
              "$first":"$strokeIndex"
            },
            scoringAverage:{
              "$first":"$scoringAverage"
            },
            geoLocation:{
              "$first":"$geoLocation"
            },
            firstLatitude:{
              "$first":"$firstLatitude"
            },
            firstLongitude:{
              "$first":"$firstLongitude"
            },
            secondLatitude:{
              "$first":"$secondLatitude"
            },
            secondLongitude:{
              "$first":"$secondLongitude"
            },
             CenterLatLong:{
              "$first":"$CenterLatLong"
            },
            rotateDegree:{
              "$first":"$rotateDegree"
            },
            updatedAt:{
              "$first":"$updatedAt"
            },
          
          
          
        }
      },
      {
        $project:{
          _id:1,
          holeNumber:1,
          par:1,
          firstLatitude:1,
          firstLongitude:1,
          secondLatitude:1,
          secondLongitude:1,
          blueYard:1,
          whiteYard:1,
          yellowYard:1,
          redYard:1,
          courseId:1,
          strokeIndex:1,
          geoLocation:1,
          scoringAverage:1,
          CenterLatLong:1,
          updatedAt:1,
          rotateDegree:1

        }
      },
      {
        $sort:{updatedAt:-1}
      },
      { 
        '$facet'    : {
        metadata: [ { $count: "total" }, { $addFields: { page: page+1, limit:limit } } ],
        data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
         } 
    }
    ]).exec();

    return aggregate;

  }

  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return CourseDetailSchema.findOne(params).exec();
  }


  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return CourseDetailSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }

  static deleteAll(id) {
    
    return CourseDetailSchema.deleteMany({courseId:id}).exec()
    .then((data) => {

      return data;
    });
  }


}

module.exports = CourseDetailBusiness;
