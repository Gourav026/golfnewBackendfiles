var { UserSchema } =require('../schema/api')
var fs = require('fs')

class UserBusiness {
  /**
   * create a new user
   * @param  {Object} data user data
   * @return {Promise}
   */
  static create(data) {
    var newUser = new UserSchema(data);
    return newUser.save().then((user) => {
      //fire event to another sides
    console.log('user--->',user)
    return user
    });
  }

  /**
   * update user
   * @param  {Object} Mongoose user object
   * @return {Promise}
   */
  static update(user) {
    return user.save().then((updated) => {
    return updated
     
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data user data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of users
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted')
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(params.contactNumber){
        condition.contactNumber = params.contactNumber;
    }
    
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    let queryName = ''
		if(params.searchName != 'undefined'){

      queryName = {
          "$or": [{
              "firstName": new RegExp(params.searchName, 'i')
          }, {
              "lastName": new RegExp(params.searchName, 'i')
          }]
      }
    }

     if(params.limit){
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page -1;
        skip =   page*limit;
      }
      if(params.role){
        condition.role = params.role;

       }
       console.log('limit',limit)

       condition = ( params.searchName != 'undefined' || params.searchName !== '' ) ? 
       { ...condition ,...queryName} : condition

       var aggregate = UserSchema.aggregate([
        {
            $match: condition
        },
        {
          $lookup:{
            from:'countries',
            localField:'countryId',
            foreignField:'_id',
            as:'countryId'
          }
        },
        {
          $unwind:{
            path:'$countryId', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $lookup:{
            from:'states',
            localField:'stateId',
            foreignField:'_id',
            as:'stateId'
          }
        },
        {
          $unwind:{
            path:'$stateId', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $lookup:{
            from:'cities',
            localField:'cityId',
            foreignField:'_id',
            as:'cityId'
          }
        },
        {
          $unwind:{
            path:'$cityId', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $lookup:{
            from:'users',
            localField:'friendList',
            foreignField:'_id',
            as:'friendList'
          }
        },
        {
          $unwind:{
            path:'$friendList', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $lookup:{
            from:'users',
            localField:'unFriendList',
            foreignField:'_id',
            as:'unFriendList'
          }
        },
        {
          $unwind:{
            path:'$unFriendList', 
            preserveNullAndEmptyArrays : true
          }
        },
        {
          $project : {
              _id : 1,
              firstName : 1,
              lastName: 1,
              contactNumber: 1,
              email: 1,
              gender: 1,
              age: 1,
              countryId:{
                _id:"$countryId._id",
                name:"$countryId.name",
                status:"$countryId.status"
              },
              stateId:{
                _id:"$stateId._id",
                name:"$stateId.name",
                status:"$stateId.status"
              },
              cityId:{
                _id:"$cityId._id",
                name:"$cityId.name",
                status:"$cityId.status"
              },
              friendList:{
                _id:"$friendList._id",
                firstName:"$friendList.firstName",
                lastName:"$friendList.lastName",
                photo:"$friendList.photo"
              },
              unFriendList:{
                _id:"$unFriendList._id",
                firstName:"$unFriendList.firstName",
                lastName:"$unFriendList.lastName",
                photo:"$unFriendList.photo"
              },  
              photo   :  1,    
              imageMediumPath   :  1,    
              imageThumbPath   :  1,    
              status: 1,
              authToken: 1,
              geoLocation:1,
              updatedAt:1

          }
      }, 
        {
            $group : {
                _id :"$_id",
                firstName : {
                    "$first": "$firstName"
                },
                lastName : {
                    "$first": "$lastName"
                },
                photo : {
                    "$first": "$photo"
                },
                gender : {
                    "$first": "$gender"
                },
                email : {
                    "$first": "$email"
                },
                contactNumber : {
                    "$first": "$contactNumber"
                },
                age : {
                    "$first": "$age"
                },
                countryId : {
                    "$first": "$countryId"
                },
                stateId : {
                    "$first": "$stateId"
                },
                cityId : {
                    "$first": "$cityId"
                },
                friendList : {
                    "$addToSet": "$friendList"
                },
                unFriendList : {
                    "$addToSet": "$unFriendList"
                },
                geoLocation : {
                  "$first": "$geoLocation"
                },
                imageMediumPath : {
                  "$first": "$imageMediumPath"
                },
                imageThumbPath : {
                  "$first": "$imageThumbPath"
                },
                authToken : {
                    "$first": "$authToken"
                },
                status : {
                    "$first": "$status"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                firstName : 1,
                lastName: 1,
                contactNumber: 1,
                email: 1,
                gender: 1,
                age: 1,
                countryId: 1,
                stateId   :  1,
                friendList   :  1,
                unFriendList   :  1,
                photo   :  1,
                imageMediumPath   :  1,    
                imageThumbPath   :  1,    
                cityId: 1,
                status: 1,
                authToken: 1,
                geoLocation:1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : {
            metadata: [ { $count: "total" }, { $addFields: { page: page+1, limit: limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }

  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return UserSchema.findOne(params).exec();
  }

  static findOneByAdmin(params) {
    return UserSchema.findOne(params).exec();
  }

  static forgotPassword(params,newPass) {
    console.log('business newPass---',newPass)
    console.log('business params---',params)
    return UserSchema.findOne(params, '-salt -password -socialLogin, -otp').exec().then((user) => {
    console.log('business user---',user)
    user.password = newPass;
    user.otp = "";

    UserBusiness.update(user)
    .then((user) => {

    });
    return user;
    
    });
  }

  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return UserSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }
  /**
   * Unlink all data by query
   * @param  {Object} data user data
   * @return {Promise}
   */
  static unlinkFile(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {

      let filePath = `./public/${params}`;
      fs.unlink(filePath, (err) => {
          if (err) {
              console.log('err', err);
              reject(err)
          } else {
              console.log(params + ' was deleted');
              resolve(params + ' was deleted');

          }
      });
    });

    return promise;
  }


 /**
   * scorecard  data fetching
   * @param  {Object} data user data
   * @return {Promise}
   */
  static userList(params){

    console.log('find hitted');
   
    
    let ObjectId = require('mongoose').Types.ObjectId;
    let condition = {role:'user'};
    let limit = 10;
    let sort = 'createdAt';
    let order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)},
      role:'user'
      }
    }
    //console.log("hiiiii-..")
    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }

   return UserSchema.find(condition).sort({name:1}).exec();


   }
 /**
   * Verify Auth
   * @param  {Object} data user data
   * @return {Promise}
   */
   static  verifyAuth (req,res){
    let token;
   let promise = new Promise((resolve, reject)=>{
   // 1st task get the token
   console.log('req---->',req)
   //verify auth token from jwt

     
      token = req.authorization;
      let tokenSplit = req.authorization.split(' ')

      token = tokenSplit[1];

      console.log('token--->',token)
      console.log('token--->',tokenSplit)
     //  var decoded = jwt.verify(token, 'shhhhh');
     //  console.log('decoded----->',decoded);

       jwt.verify(token, config.secrets.session, function(err, decoded) {

         try {
           console.log('decoded----->',decoded);
           if (decoded._id) {
             resolve('Authentication Successs')
             console.log('req.params--->',req.params);
             
           }
           
            else {
              reject('Authentication failed')
            }
           
         
         } catch(err) {
           console.log('err--->',err)
         }
      });

   })
   return promise
  }



}

module.exports = UserBusiness;
