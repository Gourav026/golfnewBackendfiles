'use strict';

let {FaqBusiness}=require('../../businesses');
const faq = require('../../schema/api/faq');
let {FaqValidator}= require('../../validators');

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  
  
const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
        
}



class FaqController{


    //========================================get list of FAq ==========================================
    static index(req, res) {
        if(req.query.limit!='undefined'){
                req.query.limit = parseInt(req.query.limit);
            }
            if(req.query.offset!='undefined'){
                req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return FaqBusiness.find(req.query)
        .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'FAQ List', data)
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
  }


    //========================================create new FAq ==========================================
    static create(req,res,next)
    {
        FaqValidator.validateCreaating(req.body).then(faq=>{
            faq.title=req.body.title? req.body.title: faq.title;
            faq.description=req.body.description? req.body.description: faq.description;

            FaqBusiness.create(faq).then(data=>{
                console.log('data',data)
                handleResponse(res, 200, 'Faq created Successfully', data)
            })
            .catch(err=>{
                handleResponse(res, 500, err.message, err)  
            });
        })
        .catch(err=>{
            console.log("validation error==>",err);
            validationError(res,422,err.cause.details[0].message,err);
        });
    }


     /**
   * ======================================= Update FAQ =====================================
   */
    static update(req, res, next) {
    //TODO - update validator
        FaqValidator.validateUpdating({...req.body, ...req.params})
        .then(faq => {
            console.log('req.files--->', req.files)
            var faqId = req.params.id;
            FaqBusiness.findOne({_id: faqId})
            .then(faq => {
                if (!faq) {
                return handleResponse(res, 200, 'faq Not Exist', data)
                }
                faq.description = req.body.description?req.body.description:faq.description;
                faq.title = req.body.title?req.body.title:faq.title;
                

                FaqBusiness.update(faq)
                .then((data) => {
                    console.log('data',data)
                    handleResponse(res, 200, 'faq Updated Successfully', data)
                })
                .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                });
            })
        })
        .catch(err => validationError(res, 422, err.message, err));
    }

    /**
     *====================================================== Deletes a faq =========================
     
     */
    static delete(req, res) {

        FaqValidator.validateUpdating(req.params).then(faq => {

            FaqBusiness.findOne({_id: req.params.id})
            .then(faq => {

                return FaqBusiness.delete(req.params.id)
                .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'faq Deleted Successfully', data)
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
        }) 
        .catch(err => validationError(res, 422, err.cause.details[0].message, err));
    }

}

module.exports=FaqController;
