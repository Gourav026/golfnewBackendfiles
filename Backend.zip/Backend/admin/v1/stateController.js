let {StateBusiness} =require('../../businesses/');
let {StateValidator}=require( '../../validators');

const validationError=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:false,
          response:data,
      });
}



const handleResponse=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:true,
          response:data,
      });
}



class StateController{

    //==================== Get State data =======================

    static index(req, res) {
        if(req.query.limit!='undefined'){
            req.query.limit = parseInt(req.query.limit);
        }
        if(req.query.offset!='undefined'){
            req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return StateBusiness.find(req.query)
        .then((data) => {
        console.log('data',data)
        handleResponse(res, 200, 'State List', data)
        })
        .catch((err) => {
        handleResponse(res, 500, err.message, err)
        });

    }







    //====================== Insert States =====================

    static create(req,res)
    {
        StateValidator.validateCreating(req.body)
        .then((state)=>{
            state.name = req.body.name;
            state.countryId = req.body.countryId;
            state.status = ( 
                            (req.body.status === true || req.body.status == 'true') || 
                            (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:true;
            
            StateBusiness.create(state)
            .then((data)=>{
                console.log(data);
                handleResponse(res, 200, 'State Added Successfully', data)
            })
            .catch(err=>{
                handleResponse(res, 500, 'State Added Successfully', data)
            });
            
        })
        .catch(err=>{
            validationError(res, 422, err.cause.details[0].message, err)
        });
    }


     /**
   *============================ Update State List =======================
   */
  static update(req, res, next) {
    
    StateValidator.validateUpdating({...req.body, ...req.params}).then(state => {
    console.log('req.files--->', req.files)
    var stateId = req.params.id;
    StateBusiness.findOne({_id: stateId})
      .then(state => {
        if (!state) { 
          handleResponse(res, 500, 'State Not Exist', {}) 
        }
        state.name = req.body.name?req.body.name:state.name;
        state.countryId = req.body.countryId?req.body.countryId:state.countryId;
        state.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:state.status;

          StateBusiness.update(state)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'State Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


  //================ Get List of State Start=======================
  static stateList(req,res)
  {
      if(req.query.limit!='undefined')
          req.query.limit=parseInt(req.query.limit);
      if(req.query.offset!='undefined')
          req.query.offset = parseInt(req.query.offset);
      
      console.log("index hitted");

      return StateBusiness.findByAdmin(req.query)
      .then((data)=>{
          console.log('data',data)
          handleResponse(res, 200, 'State List', data)
      })
      .catch((err)=>{
          console.log('error=',err)
          handleResponse(res, 500, err.message, err)
      })
      
  }
  //================ Get List of State End=======================


 /**
   *=========================== Deletes a state =================
   * restriction: 'admin'
   */
  static delete(req, res) {

    StateValidator.validateUpdating(req.params).then(state => {

        StateBusiness.findOne({_id: req.params.id})
        .then(state => {

            return StateBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'State deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

}

module.exports= StateController;