'use strict'

let {CommentValidator} =require('../../validators')
const {CommentBusiness, UserBusiness} = require('../../businesses')
let config =require('../../config/environment');
const { Uploader } = require('../../components');
const newsFeed = require('../../schema/api/newsFeed');
var async = require('async')

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  
  
  const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
        
  }


class CommentController{
    

    /**
   * Get list of courses
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CommentBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'News Feed List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }



    //========================================create new Comment ==========================================
    static create(req,res,next)
    {
        CommentValidator.validateCreating(req.body)
        .then(comments=>{

            comments.comment=req.body.comment;
            comments.userId=req.body.userId;
            comments.newsFeedId=req.body.newsFeedId;
            comments.module=req.body.module;
            console.log("userId==",comments.userId)
            CommentBusiness.create(comments)
            .then((data)=>{
                handleResponse(res, 200, 'Comment description Added Successfully', data)    
            })
            .catch((err)=>{
                console.log("err=",err);
                handleResponse(res, 500, err, err)
            })

        })
        .catch((err)=>{
            console.log("validation error.,",err);
            validationError(res, 422, err, err);

        })

    }


    static update(req, res, next)
    {
        CommentValidator.validateUpdating({...req.body, ...req.params})
        .then(newsFeed=>{
            let commentsId=req.params.id;
            let fileType='';
            CommentBusiness.findOne({_id:commentsId})
                .then(comments =>{
                    if(!comments)
                    {
                        handleResponse(res, 500, 'News FeedDetail does Not Exist', {}) 
                    }
                    comments.comment=req.body.comment?req.body.comment:comments.comment;
                    comments.userId=req.body.userId?req.body.userId:comments.userId;
                    comments.newsFeedId=req.body.newsFeedId?req.body.newsFeedId:comments.newsFeedId;

                    comments.module=(req.body.module!=undefined || req.body.module=="")?req.body.module:comments.module;



                    console.log("req.body==",req.body)
                    console.log("update newsFeedId==",req.body.newsFeedId)
                    console.log("update module==",req.body.module)
                    console.log("updatedd module==","------------  "+comments.module)

                    CommentBusiness.update(comments)
                    .then(data=>{
                        handleResponse(res,200,"newsFeed Detail updated successfully",data)
                    })
                    .catch(err=>{
                        handleResponse(res,500,err,err);
                    })
                    
                    
                })
                .catch((err)=>{
                    console.log("sending err",err);
                    handleResponse(res, 500, err.message, err);
                });
        })
        .catch(err => 
            validationError(res, 422, err.cause.details[0].message, err)
        );
    }


    /**
   * Deletes a newsFeed
   * restriction: 'newsFeed'
   */
  static delete(req, res) {

    CommentValidator.validateUpdating(req.params).then(comments => {

        CommentBusiness.findOne({_id: req.params.id})
        .then(comments => {

            return CommentBusiness.delete(req.params.id)
            .then((data) => {

                console.log('data',data)
                handleResponse(res, 200, 'Comment Deleted Successfully', data)
                
            })
            .catch((err) => {
                handleResponse(res, 500, err.message, err)
            });
        
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

}
module.exports=CommentController;