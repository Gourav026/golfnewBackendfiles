'use strict';

var { CityBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { CityValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      success:false,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        success:true,
        response:data
      });
}


class CityController {
  /**
   * Get list of citys
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CityBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'City List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new city
   */
  static create(req, res, next) {

    CityValidator.validateCreating(req.body).then( city => {
        city.name = req.body.name;
        city.countryId = req.body.countryId;
        city.stateId = req.body.stateId;
        city.latitude = req.body.latitude;
        city.longitude = req.body.longitude;
        city.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:true
             
         CityBusiness.create(city)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'City Added Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));



  }


   /**
   * Update Profile City
   */
  static update(req, res, next) {
    //TODO - update validator
    CityValidator.validateUpdating({...req.body, ...req.params}).then(city => {
    console.log('req.files--->', req.files)
    var cityId = req.params.id;
    CityBusiness.findOne({_id: cityId})
      .then(city => {
        if (!city) { 
          handleResponse(res, 500, 'City Not Exist', {}) 
        }
        city.name = req.body.name?req.body.name:city.name;
        city.countryId = req.body.countryId?req.body.countryId:city.countryId;
        city.stateId = req.body.stateId?req.body.stateId:city.stateId;
        city.latitude = req.body.latitude;
        city.longitude = req.body.longitude;
        city.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:city.status;

          CityBusiness.update(city)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'City Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  //================ Get List of City Start=======================
  static cityList(req,res)
  {
      if(req.query.limit!='undefined')
          req.query.limit=parseInt(req.query.limit);
      if(req.query.offset!='undefined')
          req.query.offset = parseInt(req.query.offset);
      
      console.log("index hitted");

      return CityBusiness.findByAdmin(req.query)
      .then((data)=>{
          console.log('data',data)
          handleResponse(res, 200, 'City List', data)
      })
      .catch((err)=>{
          console.log('error=',err)
          handleResponse(res, 500, err.message, err)
      })
      
  }
  //================ Get List of City End=======================

  /**
   * Deletes a city
   * restriction: 'admin'
   */
  static delete(req, res) {

    CityValidator.validateUpdating(req.params).then(city => {

        CityBusiness.findOne({_id: req.params.id})
        .then(city => {

            return CityBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'City deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = CityController;
