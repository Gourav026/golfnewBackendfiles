'use strict';


var { TermBusiness } = require('../../businesses')
var { TermValidator, parseJoiError } = require('../../validators')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      success:false,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        success:true,
        message:message,
        response:data
      });
}


class TermController {
  /**
   * Get list of term
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);

    return TermBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Term List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new term
   */
  static create(req, res, next) {

    TermValidator.validateCreating(req.body).then(term => {
      term.description = req.body.description;
      term.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      
        TermBusiness.create(term)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'Term Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }


   /**
   * Update Profile Term
   */
  static update(req, res, next) {
    //TODO - update validator
    TermValidator.validateUpdating({...req.body, ...req.params}).then(term => {
    console.log('req.files--->', req.files)
    var termId = req.params.id;
    TermBusiness.findOne({_id: termId})
      .then(term => {
        if (!term) {
          return handleResponse(res, 200, 'Term Not Exist', data)
        }
        term.description = req.body.description?req.body.description:term.description;

        term.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:term.status;

          TermBusiness.update(term)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Term Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a term
   * restriction: 'term'
   */
  static delete(req, res) {

    TermValidator.validateUpdating(req.params).then(term => {

        TermBusiness.findOne({_id: req.params.id})
        .then(term => {

            return TermBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Term Deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

}

module.exports = TermController;
