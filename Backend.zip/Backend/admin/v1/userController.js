'use strict';


var { UserModel } = require('../../schema/api')
var { UserBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { UserValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')


function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      success:false,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        success:true,
        message:message,
        response:data
      });
}


class UserController {
  /**
   * Get list of user
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    req.query.role ='user'
    return UserBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'User List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  
 /**
   * Get scorecard of user
   */
  
  static userList(req,res,next)
  {

      if(req.query.limit!='undefined')
          req.query.limit=parseInt(req.query.limit);
      if(req.query.offset!='undefined')
          req.query.offset = parseInt(req.query.offset);
      
      console.log("index hitted");

      return UserBusiness.userList(req.query)
      .then((data)=>{
          console.log('data',data)
          handleResponse(res, 200, 'User List', data)
      })
      .catch((err)=>{
          console.log('error=',err)
          handleResponse(res, 500, err.message, err)
      })
      
  }

  /**
   * Creates a new user
   */
  static create(req, res, next) {

    UserValidator.validateCreating(req.body).then(user => {
      user.firstName = req.body.firstName;
      user.lastName = req.body.lastName;
      user.email = req.body.email;
      user.contactNumber = req.body.contactNumber;
      user.countryId = req.body.countryId;
      user.stateId = req.body.stateId;
      user.cityId = req.body.cityId;
      user.geoLocation=req.body.geoLocation?req.body.geoLocation:user.geoLocation;
      user.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      
      user.role = 'user';
      user.emailVerifiedToken = Helper.StringHelper.randomString(48);
             
        UserBusiness.create(user)
        .then((data) => {
          console.log('data',data)
              
          let Func    = Uploader.uploadImageWithAvatar;
          let Payload = {firstName:data.firstName,lastName:data.lastName};

          if( req.files && req.files.photo)
          { 
             Func =  Uploader.uploadImageWithThumbnails;
             Payload = req.files.photo
          }

          Func(Payload, data._id, 'users', '/uploads/images/users/', function(err, result) {
            
            if(result)
            {
            user.photo            = result.imageFullPath;
            user.imageMediumPath  = result.imageMediumPath;
            user.imageThumbPath   = result.imageThumbPath;
            }
          });

          UserBusiness.update(user)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'User Register Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
          
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile User
   */
  static update(req, res, next) {
    //TODO - update validator
    UserValidator.validateUpdating({...req.body, ...req.params}).then(user => {
    console.log('req.files--->', req.files)
    var userId = req.params.id;
    UserBusiness.findOne({_id: userId})
      .then(user => {
        if (!user) {
          return handleResponse(res, 200, 'User Not Exist', data)
        }
        console.log("geoLocation value=",req.body.geoLocation);
        //console.log("geoLocation parsed value=",JSON.parse(req.body.geoLocation));

        user.firstName = req.body.firstName?req.body.firstName:user.firstName;
        user.lastName = req.body.lastName?req.body.lastName:user.lastName;
        user.email = req.body.email?req.body.email:user.email;
        user.contactNumber = req.body.contactNumber?req.body.contactNumber:user.contactNumber;
        user.countryId = req.body.countryId?req.body.countryId:user.countryId;
        user.stateId = req.body.stateId?req.body.stateId:user.stateId;
        user.cityId = req.body.cityId?req.body.cityId:user.cityId;
        if(req.body.geoLocation){
          user.geoLocation=JSON.parse(req.body.geoLocation)
         }
        user.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:user.status;

        if(req.body.password!='' && typeof req.body.password !='undefined'){
          user.password = req.body.password;
        }
        user.role = req.body.role?req.body.role:user.role;
        user.emailVerify = ( 
                              (req.body.emailVerify === true || req.body.emailVerify == 'true') || 
                              (req.body.emailVerify === false || req.body.emailVerify == 'false') 
                            ) ? req.body.emailVerify:user.emailVerify;

        if( req.files && req.files.photo)
        {
          //console.log('')
         if(user.photo && user.photo!=''){
              UserBusiness.unlinkFile(user.photo)
              .then( unlinkres => { console.log('unlinkres-',unlinkres)})
              .catch((err) => {
                handleResponse(res, 500, err.message, err)
              });
          }
          console.log('user.imageMediumPath--',user.imageMediumPath)
          if(user.imageMediumPath && user.imageMediumPath!=''){
            UserBusiness.unlinkFile(user.imageMediumPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          }
          if(user.imageThumbPath && user.imageThumbPath!=''){
            UserBusiness.unlinkFile(user.imageThumbPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          } 
        }
        async.waterfall([
          function(cb) { 
            if (!req.files) {
               cb();
               if (!req.files.photo) {
                cb();
               }
            }

            user.imageType = config.imageType;
            let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
            Func(req.files.photo, req.user._id, 'users', '/uploads/images/users/', function(err, result) {
             
              if(result)
              {
              user.photo  = result.imageFullPath;
              user.imageMediumPath  = result.imageMediumPath;
              user.imageThumbPath  = result.imageThumbPath;
              }
              cb();
            });
          }
        ], function() {
          UserBusiness.update(user)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'User Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  /**
   * Deletes a user
   * restriction: 'user'
   */
  static delete(req, res) {

    UserValidator.validateUpdating(req.params).then(user => {

        UserBusiness.findOne({_id: req.params.id})
        .then(user => {

            return UserBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'User Deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  static verifyauth (req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
      console.log('req.query.limit----->',req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
      console.log('req.query.offset----->',req.query.offset)
    }
    console.log('index hitted',req.query);
    
    return UserBusiness.verifyAuth({ ...req.query,...req.params,...req.headers})
     .then((data) => {
       console.log('data',data)
       handleResponse(res, 200, 'User List', data)
     })
     .catch((err) => {
       handleResponse(res, 500, err.message, err)
     });
  }




}

module.exports = UserController;
