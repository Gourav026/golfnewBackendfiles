'use-strict'

let {CountryBusiness, CourseBusiness}= require('../../businesses');
let {CountryValidator}= require('../../validators');


const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
}



const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
}

class CountryController{
    
    //================ Get List of Countries =======================
    static index(req,res)
    {
        if(req.query.limit!='undefined')
            req.query.limit=parseInt(req.query.limit);
        if(req.query.offset!='undefined')
            req.query.offset = parseInt(req.query.offset);
        
        console.log("index hitted");

        return CountryBusiness.find(req.query)
        .then((data)=>{
            console.log('data',data)
            handleResponse(res, 200, 'Country Lists', data)
        })
        .catch((err)=>{
            console.log('error=',err)
            handleResponse(res, 500, err.message, err)
        })
        
    }

  //================ Get List of Countries Start=======================
  static countryList(req,res)
  {

      if(req.query.limit!='undefined')
          req.query.limit=parseInt(req.query.limit);
      if(req.query.offset!='undefined')
          req.query.offset = parseInt(req.query.offset);
      
      console.log("index hitted");

      return CountryBusiness.findByAdmin(req.query)
      .then((data)=>{
          console.log('data',data)
          handleResponse(res, 200, 'Country List', data)
      })
      .catch((err)=>{
          console.log('error=',err)
          handleResponse(res, 500, err.message, err)
      })
      
  }
  //================ Get List of Countries End=======================


    //================ add country ==========================================
    static create(req,res,next)
    {
        CountryValidator.validateCreating(req.body)
        .then(country=>{
            country.name=req.body.name;
            country.status = ( 
                (req.body.status === true || req.body.status == 'true') || 
                (req.body.status === false || req.body.status == 'false') 
              ) ? req.body.status:true
            CountryBusiness.create(country)
            .then((data)=>{
                console.log("data=",data);
                handleResponse(res,200,"country Added Successfully", data);
            })
            .catch((err)=>{
                console.log(err.message);
                handleResponse(res, 500, err.message, err);
            })

        })
        .catch(err => validationError(res, 422, err.cause.details[0].message, err));
    }

    //================= update country ===============================
    static update(req,res,next)
    {
        CountryValidator.validateUpdating({...req.body, ...req.params})
        .then(country => {
        console.log('req.files--->', req.files)
        var countryId = req.params.id;
        CountryBusiness.findOne({_id: countryId})
            .then(country => {
            if (!country) { 
                handleResponse(res, 500, 'Country Not Exist', {}) 
            }
            country.name = req.body.name?req.body.name:country.name;
            country.status = ( 
                            (req.body.status === true || req.body.status == 'true') || 
                          (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:country.status;

            CountryBusiness.update(country)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Country Updated Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

    }

    /**
   * =========================== Deletes a country ==========================
   * restriction: 'admin'
   */
  static delete(req, res) {

    CountryValidator.validateUpdating(req.params).then(country => {

        CountryBusiness.findOne({_id: req.params.id})
        .then(country => {

            return CountryBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Country deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports=CountryController;