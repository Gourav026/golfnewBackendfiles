'use strict';

var { RoundBusiness,RoundDetailBusiness, CourseBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { RoundValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      success:statusCode ==200? true:false,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        success:statusCode ==200? true:false,
        response:data
      });
}


class RoundController {



  /**
   * Get list of users
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);    
    return RoundBusiness.findByAdmin(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Round List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new round
   */
  static start(req, res, next) {

    RoundValidator.validateCreating(req.body).then(round => {
      round.courseId      = req.body.courseId;
      round.player1       = req.body.player1;
      round.player2       = req.body.player2;
      round.player3       = req.body.player3;
      round.player4       = req.body.player4;
      round.name          = req.body.name;
      round.modeSelection = req.body.modeSelection;
      round.startingHole  = req.body.startingHole;
      round.lastRecord    = req.body.lastRecord;
      round.lastRecordBy  = req.body.lastRecordBy;

        RoundBusiness.start(round)
            .then((data) => {

				CourseBusiness.findOne({_id:round.courseId})
				.then(courseData=>{

					console.log("courseData=",courseData)
					courseData.totalTimesPlayed=courseData.totalTimesPlayed+1;

					CourseBusiness.update(courseData)
					.then(courseUpdatedData=>{
						console.log("courseUpdatedData=",courseUpdatedData)
						//handleResponse(res, 200, 'Round and course Updated Successfully ', data)
					})
				})
				.catch(err=>{
					handleResponse(res, 500, 'Round Started Successfully but invalid course', err)
				})
				//handleResponse(res, 200, 'Round Updated Successfully', data)
				if(req.body.scoredetail)
				{
				let roundDetails=JSON.parse(req.body.scoredetail);
				roundDetails.map((value,index)=>{
						console.log("value in scoredetail=",value);
						let details={roundId:data._id,...value};

						console.log("details=",details);
						roundDetails[index]=details;

				})
				console.log("roundDetailUpdated=",roundDetails);
				RoundDetailBusiness.bulkUpdate(roundDetails)
				.then((data)=>{
					console.log('data',data)
					handleResponse(res, 200, 'Round and RoundDetail  Updated Successfully', data)
				})
				.catch((err)=>{
					handleResponse(res,500,err.message,err);
				})
				}
				else
				{
					handleResponse(res, 200, 'Round Updated Successfully', data)
				}
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }


   /**
   * Update Round
   */
  static update(req, res, next) {
    //TODO - update validator
    RoundValidator.validateUpdating({...req.body, ...req.params}).then(round => {
    console.log('req.files--->', req.files)
    var roundId = req.params.id;
    RoundBusiness.findOne({_id: roundId})
      .then(round => {
        if (!round) { 
          handleResponse(res, 500, 'round Not Exist', {}) 
        }
        console.log('round-->',round);
        round.courseId      = req.body.courseId?req.body.courseId:round.courseId;
        round.player1       = req.body.player1?req.body.player1:round.player1;
        round.player2       = req.body.player2?req.body.player2:round.player2;
        round.player3       = req.body.player3?req.body.player3:round.player3;
        round.player4       = req.body.player4?req.body.player4:round.player4;
        round.name          = req.body.name?req.body.name:round.name;
        round.modeSelection = req.body.modeSelection?req.body.modeSelection:round.modeSelection;
        round.startingHole  = req.body.startingHole?req.body.startingHole:round.startingHole;
        round.lastRecord    = req.body.lastRecord?req.body.lastRecord:round.lastRecord;
        round.lastRecordBy  = req.body.lastRecordBy?req.body.lastRecordBy:round.lastRecordBy;

          RoundBusiness.update(round)
          .then((data) => {
            console.log('data',data)
            //handleResponse(res, 200, 'Round Updated Successfully', data)
            if(req.body.scoredetail)
             {
                let roundDetails=JSON.parse(req.body.scoredetail);
                roundDetails.map((value,index)=>{
                     console.log("value in scoredetail=",value);
                      // let details={roundId:data._id,...value[0]};

                      // console.log("details=",details);
                      // roundDetails[index]=details;

                })
                console.log("roundDetailUpdated=",roundDetails);
                RoundDetailBusiness.bulkUpdate(roundDetails)
                .then((data)=>{
                   console.log('data',data)
                   handleResponse(res, 200, 'Round and RoundDetail  Updated Successfully', data)
                })
                .catch((err)=>{
                   handleResponse(res,500,err.message,err);
                })
             }
             else
             {
               handleResponse(res, 200, 'Round Updated Successfully', data)
             }
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
   
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


  /**
   *=========================== Deletes a round =================
   * restriction: 'admin'
   */
  static delete(req, res) {

    RoundValidator.validateUpdating(req.params).then(round => {

        RoundBusiness.findOne({_id: req.params.id})
        .then(round => {

            return RoundBusiness.delete(req.params.id)
            .then((data) => {
                console.log('data',data)
                //handleResponse(res, 200, 'Round deleted Successfully', data)
                RoundDetailBusiness.find({roundId :  req.params.id})//after deleting round all the round details must be deleted
                .then(round=>{
                    return RoundDetailBusiness.deleteAll(req.params.id)
                    .then((data)=>{
                        console.log('all rounddetails deleted data =',data)
                        handleResponse(res, 200, 'Round and RoundDetails deleted Successfully', data)
                    })
                    .catch((err) => {
                        handleResponse(res, 500, err.message, err)
                    });
                    })
                .catch((err) => {   
                    handleResponse(res, 500, err.message, err)
                }) 

              //handleResponse(res, 200, 'Round deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Authentication callback
   */
  static authCallback(req, res, next) {
    res.redirect('/');
  }


}

module.exports = RoundController;
