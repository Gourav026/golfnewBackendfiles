'use strict';


var { PrivacyBusiness } = require('../../businesses')
var { PrivacyValidator, parseJoiError } = require('../../validators')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      success:false,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        success:true,
        message:message,
        response:data
      });
}


class PrivacyController {
  /**
   * Get list of privacy
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);

    return PrivacyBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Privacy List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new privacy
   */
  static create(req, res, next) {

    PrivacyValidator.validateCreating(req.body).then(privacy => {
      privacy.description = req.body.description;
      privacy.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      
        PrivacyBusiness.create(privacy)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'Privacy Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }


   /**
   * Update Profile Privacy
   */
  static update(req, res, next) {
    //TODO - update validator
    PrivacyValidator.validateUpdating({...req.body, ...req.params}).then(privacy => {
    console.log('req.files--->', req.files)
    var privacyId = req.params.id;
    PrivacyBusiness.findOne({_id: privacyId})
      .then(privacy => {
        if (!privacy) {
          return handleResponse(res, 200, 'Privacy Not Exist', data)
        }
        privacy.description = req.body.description?req.body.description:privacy.description;

        privacy.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:privacy.status;

          PrivacyBusiness.update(privacy)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Privacy Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a privacy
   * restriction: 'privacy'
   */
  static delete(req, res) {

    PrivacyValidator.validateUpdating(req.params).then(privacy => {

        PrivacyBusiness.findOne({_id: req.params.id})
        .then(privacy => {

            return PrivacyBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Privacy Deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

}

module.exports = PrivacyController;
