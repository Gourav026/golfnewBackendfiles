'use strict';


var { UserModel } = require('../../schema/api')
var { UserBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { UserValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')


function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      success:false,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        success:true,
        message:message,
        response:data
      });
}


class AdminController {
  /**
   * Get list of admin
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }



    console.log('index hitted',req.query);
    req.query.role ='admin'
    return UserBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Admin List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new user
   */
  static create(req, res, next) {

    UserValidator.validateCreating(req.body).then(admin => {
      admin.firstName = req.body.firstName;
      admin.lastName = req.body.lastName;
      admin.email = req.body.email;
      admin.contactNumber = req.body.contactNumber;
      admin.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      
      admin.role = 'admin';
      admin.emailVerifiedToken = Helper.StringHelper.randomString(48);
             
        UserBusiness.create(admin)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'Admin Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile User
   */
  static update(req, res, next) {
    //TODO - update validator
    UserValidator.validateUpdating({...req.body, ...req.params}).then(user => {
    console.log('req.files--->', req.files)
    var userId = req.params.id;
    UserBusiness.findOne({_id: userId})
      .then(user => {
        if (!user) {
          return handleResponse(res, 200, 'User Not Exist', data)
        }
        user.firstName = req.body.firstName?req.body.firstName:user.firstName;
        user.lastName = req.body.lastName?req.body.lastName:user.lastName;
        user.email = req.body.email?req.body.email:user.email;
        user.contactNumber = req.body.contactNumber?req.body.contactNumber:user.contactNumber;
        user.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:user.status;

        if(req.body.password!='' && typeof req.body.password !='undefined'){
          user.password = req.body.password;
        }
        user.role = req.body.role?req.body.role:user.role;
        user.emailVerify = ( 
                              (req.body.emailVerify === true || req.body.emailVerify == 'true') || 
                              (req.body.emailVerify === false || req.body.emailVerify == 'false') 
                            ) ? req.body.emailVerify:user.emailVerify;

          console.log(req.files+"         "+req.files.photo);
        if( req.files && req.files.photo)
        {
          //console.log('')
         if(user.photo && user.photo!=''){
              UserBusiness.unlinkFile(user.photo)
              .then( unlinkres => { console.log('unlinkres-',unlinkres)})
              .catch((err) => {
                handleResponse(res, 500, err.message, err)
              });
          }
          console.log('user.imageMediumPath--',user.imageMediumPath)
          if(user.imageMediumPath && user.imageMediumPath!=''){
            UserBusiness.unlinkFile(user.imageMediumPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          }
          if(user.imageThumbPath && user.imageThumbPath!=''){
            UserBusiness.unlinkFile(user.imageThumbPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          } 
        }
        async.waterfall([
          function(cb) { 
            if (!req.files) {
               cb();
               if (!req.files.photo) {
                cb();
               }
            }

            user.imageType = config.imageType;
            let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
            Func(req.files.photo, req.user._id, 'admin', '/uploads/images/admin/', function(err, result) {
             
              if(result)
              {
              user.photo  = result.imageFullPath;
              user.imageMediumPath  = result.imageMediumPath;
              user.imageThumbPath  = result.imageThumbPath;
              }
              cb();
            });
          }
        ], function() {
          UserBusiness.update(user)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Admin Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  /**
   * Deletes a user
   * restriction: 'admin'
   */
  static delete(req, res) {

    UserValidator.validateUpdating(req.params).then(user => {

        UserBusiness.findOne({_id: req.params.id})
        .then(user => {

            return UserBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Admin Deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }




}

module.exports = AdminController;
