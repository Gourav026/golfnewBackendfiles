'use strict'

let {NewsFeedValidator} =require('../../validators')
const {NewsFeedBusiness, UserBusiness} = require('../../businesses')
let config =require('../../config/environment');
const { Uploader } = require('../../components');
const newsFeed = require('../../schema/api/newsFeed');
var async = require('async')

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  
  
  const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
        
  }


class NewsFeedController{
    

    /**
   * Get list of courses
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return NewsFeedBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'News Feed List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }


  //================== Get all NewsFeed List =======================
  static newsFeedList(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return NewsFeedBusiness.newsFeedList(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'NewsFeed List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }


    //========================================create new NewsFeed ==========================================
    static create(req,res,next)
    {
        NewsFeedValidator.validateCreating(req.body)
        .then(async newsFeed=>{

            newsFeed.description=req.body.description;
            newsFeed.userId=req.body.userId;
            console.log("userId==",newsFeed.userId)
            NewsFeedBusiness.create(newsFeed)
            .then((data)=>{

                console.log("newsFeed data=",data)
                //================= uploading photo ==================
                if(req.files && req.files.photo)
                {
                    data.imageType=config.imageType;

                    let Func=config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3: Uploader.uploadImageWithThumbnails;
                    
                    Func(req.files.photo, data._id, 'newsfeeds', '/uploads/images/newsfeeds/',(err,result)=>{
                        console.log("result=",result);

                        if(result)
                        {
                            data.photo  = result.imageFullPath;
                            data.imageMediumPath  = result.imageMediumPath;
                            data.imageThumbPath  = result.imageThumbPath;
                        }
                        NewsFeedBusiness.update(data)
                        .then((dataUpdated)=>{
                            console.log('data',dataUpdated)
                            handleResponse(res, 200, "News feed photo and description added successfully", dataUpdated)
                            
                            
                        })
                        .catch((err)=>{
                            handleResponse(res, 500, err.message, err)
                        })
                    });
                }
                // ======================= uploading video ================================
                else if(req.files && req.files.video)
                {
                    Uploader.uploadVideo(req.files.video, data._id,'newsfeeds', '/uploads/videos/newsfeeds/',(err, resultData)=>{
                        console.log("result data=",resultData)
                        if(resultData)
                        {
                            data.video=resultData.video;
                            data.videoThumb=resultData.videoThumb;
                        }
                        NewsFeedBusiness.update(data)
                        .then(videoUpdatedData=>{
                            console.log("videoUpdated data=",videoUpdatedData);
                            handleResponse(res, 200, 'NewsFeed  video and decription  Added Successfully', videoUpdatedData)
                        })
                        .catch(err=>{
                            handleResponse(res, 500, err.message, err)
                        })
                        
                    })
                } 
                else      
                {
                    handleResponse(res, 200, 'NewsFeed description Added Successfully', data)
                }       
                    
                
            })
            .catch((err)=>{
                handleResponse(res, 500, err.message, err)
            })
            

        })
        .catch((err)=>{
            validationError(res, 422, err.cause.details[0].message, err);

        })

    }


    static update(req, res, next)
    {
        NewsFeedValidator.validateUpdating({...req.body, ...req.params})
        .then(newsFeed=>{
            let newsFeedId=req.params.id;
            let fileType='';
            NewsFeedBusiness.findOne({_id:newsFeedId})
                .then(newsFeed =>{
                    if(!newsFeed)
                    {
                        handleResponse(res, 500, 'News Feed does Not Exist', {}) 
                    }
                    newsFeed.description=req.body.description?req.body.description:newsFeed.description;
                    newsFeed.userId=req.body.userId?req.body.userId:newsFeed.userId;
                    newsFeed.likedBy=req.body.likedBy?JSON.parse(req.body.likedBy):newsFeed.likedBy;
                    // if(req.body.likedBy)
                    // {
                    //     let likedById=req.body.likedBy;
                    //     const index = newsFeed.likedBy.indexOf(likedById);
                    //     console.log("update index==",index)
                    //     if(index>-1)
                    //     {
                    //         newsFeed.likedBy.splice(index,1);
                    //     }
                    //     else{
                    //         newsFeed.likedBy.push(likedById);
                    //     }
                            
                    // }
                    console.log("update likedBy==",newsFeed.likedBy)
                    
                    if(req.files)
                    {
                        console.log("in req.files")

                        if(req.files && req.files.photo && newsFeed.photo && newsFeed.photo!='')
                        {
                            fileType="photo"
                            console.log("fileType=",fileType);

                            UserBusiness.unlinkFile(newsFeed.photo)
                            .then(unlinkres=>{
                                console.log('unlinkres-',unlinkres)
                            })
                            .catch((err) => {
                                handleResponse(res, 500, err.message, err)
                            });
                        }
                        if(req.files && req.files.video && newsFeed.video && newsFeed.video!='')
                        {

                            fileType="video"
                            console.log("fileType=",fileType);
                            UserBusiness.unlinkFile(newsFeed.video)
                            .then(unlinkres=>{
                                console.log('unlinkres-',unlinkres)
                            })
                            .catch((err) => {
                                handleResponse(res, 500, err.message, err)
                            });
                        }
                    }
                    async.waterfall([

                        
                        function(cb){
                            
                            if(!req.files){
                                console.log("in waterfall");
                                cb();
                                // if(fileType==''){
                                //     cb();
                                // }
                                
                            }
                            
                            console.log("going to update....")
                            let Func = (req.files && req.files.photo) ? Uploader.uploadImageWithThumbnails : Uploader.uploadVideo;
                            if(req.files && req.files.photo)
                            {
                                Func(req.files.photo, req.params.id,'newsfeeds', '/uploads/images/newsfeeds/',(err,result)=>{
                                    console.log("result=",result);
            
                                    if(result)
                                    {
                                        
                                        newsFeed.photo  = result.imageFullPath;
                                        newsFeed.imageMediumPath  = result.imageMediumPath;
                                        newsFeed.imageThumbPath  = result.imageThumbPath;

                                        newsFeed.video="";
                                    }
                                    cb();
                                });
                            }
                            else if(req.files && req.files.video){
                                console.log("uploading video...........")
                                Func(req.files.video, req.params.id,'newsfeeds', '/uploads/videos/newsfeeds/',(err,result)=>{
                                    console.log("result=",result);
            
                                    if(result)
                                    {
                                        newsFeed.video=result.video;
                                        newsFeed.videoThumb=result.videoThumb;
                                        
                                        newsFeed.photo  = ""
                                        newsFeed.imageMediumPath  ="";
                                        newsFeed.imageThumbPath  = "";
                                        
                                    }
                                    cb();
                                });
                            }

                        }
                    ],()=>{
                        NewsFeedBusiness.update(newsFeed)
                        .then((data)=>{
                            handleResponse(res, 200, 'NewsFeed Updated Successfully', data)
                        })
                        .catch((err)=>{
                            handleResponse(res, 500, err.message, err);
                        });
                    })
                })
                .catch((err)=>{
                    console.log("sending err",err);
                    handleResponse(res, 500, err.message, err);
                });
        })
        .catch(err => 
            validationError(res, 422, err.cause.details[0].message, err)
        );
    }


    /**
   * Deletes a newsFeed
   * restriction: 'newsFeed'
   */
  static delete(req, res) {

    NewsFeedValidator.validateUpdating(req.params).then(newsFeed => {

        NewsFeedBusiness.findOne({_id: req.params.id})
        .then(newsFeed => {

            return NewsFeedBusiness.delete(req.params.id)
            .then((data) => {

                // if(data && data.photo && data.photo!='')
                // {
                    
                //     let dir=data.photo.split("/");
                //     let directory= "/"+dir[1]+"/"+dir[2]+"/"+dir[3]+"/"+dir[4];
                //     console.log("photo",data.photo)
                //     console.log("dir=",dir)
                //     console.log("directory=",directory)

                //     UserBusiness.unlinkFile(directory)
                //     .then(unlinkres=>{
                //         console.log('photo unlinkres-',unlinkres)
                //         if(data.video && data.video!='')
                //         {
                //             let dir=data.photo.split("/");
                //             let directory= dir[0]+"/"+dir[1]+"/"+dir[2]+"/"+dir[3];
                //             UserBusiness.unlinkFile(directory)
                //             .then(unlinkres=>{
                //                 handleResponse(res, 200, 'NewsFeed Deleted Successfully', data)
                //                 console.log('video unlinkres-',unlinkres)
                //             })
                //             .catch((err) => {
                //                 handleResponse(res, 500, err.message, err)
                //             });
                //         }
                //         else{

                //             console.log('data',data)
                //             handleResponse(res, 200, 'NewsFeed Deleted Successfully', data)
                //         }
                //     })
                //     .catch((err) => {
                //         handleResponse(res, 500, err.message, err)
                //     });
                // }
                
                // if(data.video && data.video!='')
                // {
                //     let dir=data.photo.split("/");
                //     let directory="/"+ dir[0]+"/"+dir[1]+"/"+dir[2]+"/"+dir[3];
                //     UserBusiness.unlinkFile(directory)
                //     .then(unlinkres=>{
                //         console.log('video unlinkres-',unlinkres)
                //     })
                //     .catch((err) => {
                //         handleResponse(res, 500, err.message, err)
                //     });
                // }
                
                console.log('data',data)
                handleResponse(res, 200, 'NewsFeed Deleted Successfully', data)
                
            })
            .catch((err) => {
                handleResponse(res, 500, err.message, err)
            });
        
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

}
module.exports=NewsFeedController;