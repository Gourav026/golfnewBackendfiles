'use strict';

let {FeedbackBusiness}=require('../../businesses');
const feedback = require('../../schema/api/feedback');
let {FeedbackValidator}= require('../../validators');

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  
  
const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
        
}



class FeedbackController{


    //========================================get list of Feedback ==========================================
    static index(req, res) {
        if(req.query.limit!='undefined'){
                req.query.limit = parseInt(req.query.limit);
            }
            if(req.query.offset!='undefined'){
                req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return FeedbackBusiness.find(req.query)
        .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'FEEDBACK List', data)
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
  }


    //========================================create new Feedback ==========================================
    static create(req,res,next)
    {
        FeedbackValidator.validateCreating(req.body).then(feedback => {
            feedback.userId = req.body.userId?req.body.userId:feedback.userId;
            feedback.title = req.body.title;
            feedback.description = req.body.description;
            

            FeedbackBusiness.create(feedback).then(data=>{
                console.log('data',data)
                handleResponse(res, 200, 'Feedback created Successfully', data)
            })
            .catch(err=>{
                handleResponse(res, 500, err.message, err)  
            });
        })
        .catch(err=>{
            console.log("validation error==>",err);
            validationError(res,422,err.cause.details[0].message,err);
        });
    }


     /**
   * ======================================= Update Feedback =====================================
   */
    static update(req, res, next) {
    //TODO - update validator
        FeedbackValidator.validateUpdating({...req.body, ...req.params})
        .then(feedback => {
            console.log('req.files--->', req.files)
            var feedbackId = req.params.id;
            FeedbackBusiness.findOne({_id: feedbackId})
            .then(feedback => {
                if (!feedback) {
                return handleResponse(res, 200, 'feedback Not Exist', data)
                }
                feedback.userId = req.body.userId?req.body.userId:feedback.userId;
                feedback.description = req.body.description?req.body.description:feedback.description;
                feedback.title = req.body.title?req.body.title:feedback.title;
                

                FeedbackBusiness.update(faq)
                .then((data) => {
                    console.log('data',data)
                    handleResponse(res, 200, 'feedback Updated Successfully', data)
                })
                .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                });
            })
        })
        .catch(err => validationError(res, 422, err.message, err));
    }

    /**
     *====================================================== Deletes a faq =========================
     
     */
    static delete(req, res) {

        FeedbackValidator.validateUpdating(req.params).then(faq => {

            FeedbackBusiness.findOne({_id: req.params.id})
            .then(faq => {

                return FeedbackBusiness.delete(req.params.id)
                .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'feedback Deleted Successfully', data)
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
        }) 
        .catch(err => validationError(res, 422, err.cause.details[0].message, err));
    }

}

module.exports=FeedbackController;
