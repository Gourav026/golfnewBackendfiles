'use strict';

var express =require('express')
var passport =require('passport')
var { signToken } =require('../auth.service')
var {  UserSchema } =require('../../schema/api')
var { UserValidator, parseJoiError } = require('../../validators')
var { UserBusiness } = require('../../businesses')

var router = express.Router();

router.post('/index', function(req, res, next) {
  console.log('start hit');
 // if (req.body.type === 'user') {

    console.log('getmycontent hit',req.body);
    UserValidator.validateLogin(req.body).then(user => {

      UserBusiness.findOne({email:user.email,emailVerify:true})
      .then((data) => {

        console.log('user businss-->',data)
        if(!data)
        {
          return res.status(200).send(
            {
              statuscode:200,
              message:'User either not exist or email not verified ',
              response:{}
            });
        }
          data.authenticate(user.password, async function(err, isCorrect) {

            if (err || !isCorrect) {
              return res.status(200).send(
                {
                  statuscode:200,
                  message:'user not verify',
                  response:err || !isCorrect
                });
            }
    
            var token = signToken(data._id, 'user');
            data.authToken = token
            data.deviceId = req.body.deviceId

            UserBusiness.update(data)
            .then((updatedData) => {

              
                UserBusiness.findOne({_id: data._id})
                .then((user) => {

                  res.status(200)
                    .send(
                      {
                        statuscode:200,
                        message:"Login Successfully",
                        response:user
                      });
                })
                .catch( (err) => {
                  
                    res.status(200).send(
                      {
                        statuscode:200,
                        message:err.message,
                        response:err
                      });
                })

            })
            .catch((err) => {
              res.status(200).send(
                {
                  statuscode:200,
                  message:err.message,
                  response:err
                });
            });


          });
      })
      .catch((err) => {
        console.log('err',err)

        res.status(200).send(
          {
            statuscode:200,
            message:err.message,
            response:err
          });
      
      });

    })
    .catch((err) => 
    {
      res.status(200)
        .send({
            statuscode:200,
            message:err.cause.details[0].message,
            response:err
        });
    });
 // }

});


module.exports= router;
